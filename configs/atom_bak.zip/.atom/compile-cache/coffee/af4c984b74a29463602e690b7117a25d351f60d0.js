(function() {
  module.exports = {
    statusBar: null,
    activate: function() {},
    deactivate: function() {
      var ref;
      if ((ref = this.statusBarTile) != null) {
        ref.destroy();
      }
      return this.statusBarTile = null;
    },
    provideTerminationTerminal: function() {
      return {
        updateProcessEnv: function(variables) {
          var name, results, value;
          results = [];
          for (name in variables) {
            value = variables[name];
            results.push(process.env[name] = value);
          }
          return results;
        },
        run: (function(_this) {
          return function(commands) {
            return _this.statusBarTile.runCommandInNewTerminal(commands);
          };
        })(this),
        getTerminalViews: (function(_this) {
          return function() {
            return _this.statusBarTile.terminalViews;
          };
        })(this),
        open: (function(_this) {
          return function() {
            return _this.statusBarTile.runNewTerminal();
          };
        })(this)
      };
    },
    provideRunInTerminal: function() {
      return {
        run: (function(_this) {
          return function(commands) {
            return _this.statusBarTile.runCommandInNewTerminal(commands);
          };
        })(this),
        getTerminalViews: (function(_this) {
          return function() {
            return _this.statusBarTile.terminalViews;
          };
        })(this)
      };
    },
    consumeStatusBar: function(statusBarProvider) {
      return this.statusBarTile = new (require('./status-bar'))(statusBarProvider);
    },
    config: {
      toggles: {
        type: 'object',
        order: 1,
        properties: {
          autoClose: {
            title: 'Close Terminal on Exit',
            description: 'Should the terminal close if the shell exits?',
            type: 'boolean',
            "default": true
          },
          autoName: {
            title: 'Auto Name Terminal',
            description: 'Should the terminal name itself based on the directory of the current file open in your text editor?',
            type: 'boolean',
            "default": true
          },
          cursorBlink: {
            title: 'Cursor Blink',
            description: 'Should the cursor blink when the terminal is active?',
            type: 'boolean',
            "default": true
          },
          runInsertedText: {
            title: 'Run Inserted Text',
            description: 'Run text inserted via `termination:insert-text` as a command? **This will append an end-of-line character to input.**',
            type: 'boolean',
            "default": true
          },
          selectToCopy: {
            title: 'Select To Copy',
            description: 'Copies text to clipboard when selection happens.',
            type: 'boolean',
            "default": true
          },
          loginShell: {
            title: 'Login Shell',
            description: 'Use --login on zsh and bash.',
            type: 'boolean',
            "default": true
          },
          showToolbar: {
            title: 'Show Toolbar',
            description: 'Show toolbar above terminal window.',
            type: 'boolean',
            "default": true
          },
          cloneTerminalPlus: {
            title: 'Clone Terminal-Plus',
            description: 'Should there be a dedicated bottom panel for termination? This will give termination a similar appearance to terminal-plus. **Restart Required.**',
            type: 'boolean',
            "default": true
          }
        }
      },
      core: {
        type: 'object',
        order: 2,
        properties: {
          autoRunCommand: {
            title: 'Auto Run Command',
            description: 'Command to run on terminal initialization.',
            type: 'string',
            "default": ''
          },
          mapTerminalsTo: {
            title: 'Map Terminals To',
            description: 'Map terminals to each file or folder. Default is no action or mapping at all. **Restart required.**',
            type: 'string',
            "default": 'None',
            "enum": ['None', 'File', 'Folder']
          },
          mapTerminalsToAutoOpen: {
            title: 'Auto Open a New Terminal (For Terminal Mapping)',
            description: 'Should a new terminal be opened for new items? **Note:** This works in conjunction with `Map Terminals To` above.',
            type: 'boolean',
            "default": false
          },
          scrollback: {
            title: 'Scroll Back',
            description: 'How many lines of history should be kept?',
            type: 'integer',
            "default": 1000
          },
          shell: {
            title: 'Shell Override',
            description: 'Override the default shell instance to launch.',
            type: 'string',
            "default": (function() {
              var path;
              if (process.platform === 'win32') {
                path = require('path');
                return path.resolve(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
              } else {
                return process.env.SHELL || '/bin/bash';
              }
            })()
          },
          shellArguments: {
            title: 'Shell Arguments',
            description: 'Specify some arguments to use when launching the shell.',
            type: 'string',
            "default": ''
          },
          shellEnv: {
            title: 'Shell Environment Variables',
            description: 'Specify some additional environment variables, space separated with the form `VAR=VALUE`',
            type: 'string',
            "default": ''
          },
          workingDirectory: {
            title: 'Working Directory',
            description: 'Which directory should be the present working directory when a new terminal is made?',
            type: 'string',
            "default": 'Project',
            "enum": ['Home', 'Project', 'Active File']
          }
        }
      },
      style: {
        type: 'object',
        order: 3,
        properties: {
          animationSpeed: {
            title: 'Animation Speed',
            description: 'How fast should the window animate? A value of 0 disables animation.',
            type: 'number',
            "default": '1',
            minimum: '0',
            maximum: '100'
          },
          fontFamily: {
            title: 'Font Family',
            description: 'Override the terminal\'s default font family. **You must use a [monospaced font](https://en.wikipedia.org/wiki/List_of_typefaces#Monospace)!**',
            type: 'string',
            "default": ''
          },
          fontSize: {
            title: 'Font Size',
            description: 'Override the terminal\'s default font size.',
            type: 'string',
            "default": ''
          },
          defaultPanelHeight: {
            title: 'Default Panel Height',
            description: 'Default height of a terminal panel. **You may enter a value in px, em, or %.**',
            type: 'string',
            "default": '300px'
          },
          theme: {
            title: 'Theme',
            description: 'Select a theme for the terminal.',
            type: 'string',
            "default": 'standard',
            "enum": ['standard', 'inverse', 'linux', 'grass', 'homebrew', 'man-page', 'novel', 'ocean', 'pro', 'red', 'red-sands', 'silver-aerogel', 'solarized-dark', 'solid-colors', 'dracula', 'Christmas', 'github', 'one-dark', 'one-light', 'bliss', 'gruvbox']
          }
        }
      },
      iconColors: {
        type: 'object',
        order: 5,
        properties: {
          red: {
            title: 'Status Icon Red',
            description: 'Red color used for status icon.',
            type: 'color',
            "default": 'red'
          },
          orange: {
            title: 'Status Icon Orange',
            description: 'Orange color used for status icon.',
            type: 'color',
            "default": 'orange'
          },
          yellow: {
            title: 'Status Icon Yellow',
            description: 'Yellow color used for status icon.',
            type: 'color',
            "default": 'yellow'
          },
          green: {
            title: 'Status Icon Green',
            description: 'Green color used for status icon.',
            type: 'color',
            "default": 'green'
          },
          blue: {
            title: 'Status Icon Blue',
            description: 'Blue color used for status icon.',
            type: 'color',
            "default": 'blue'
          },
          purple: {
            title: 'Status Icon Purple',
            description: 'Purple color used for status icon.',
            type: 'color',
            "default": 'purple'
          },
          pink: {
            title: 'Status Icon Pink',
            description: 'Pink color used for status icon.',
            type: 'color',
            "default": 'hotpink'
          },
          cyan: {
            title: 'Status Icon Cyan',
            description: 'Cyan color used for status icon.',
            type: 'color',
            "default": 'cyan'
          },
          magenta: {
            title: 'Status Icon Magenta',
            description: 'Magenta color used for status icon.',
            type: 'color',
            "default": 'magenta'
          }
        }
      },
      customTexts: {
        type: 'object',
        order: 6,
        properties: {
          customText1: {
            title: 'Custom text 1',
            description: 'Text to paste when calling termination:insert-custom-text-1, $S is replaced by selection, $F is replaced by file name, $D is replaced by file directory, $L is replaced by line number of cursor, $$ is replaced by $',
            type: 'string',
            "default": ''
          },
          customText2: {
            title: 'Custom text 2',
            description: 'Text to paste when calling termination:insert-custom-text-2',
            type: 'string',
            "default": ''
          },
          customText3: {
            title: 'Custom text 3',
            description: 'Text to paste when calling termination:insert-custom-text-3',
            type: 'string',
            "default": ''
          },
          customText4: {
            title: 'Custom text 4',
            description: 'Text to paste when calling termination:insert-custom-text-4',
            type: 'string',
            "default": ''
          },
          customText5: {
            title: 'Custom text 5',
            description: 'Text to paste when calling termination:insert-custom-text-5',
            type: 'string',
            "default": ''
          },
          customText6: {
            title: 'Custom text 6',
            description: 'Text to paste when calling termination:insert-custom-text-6',
            type: 'string',
            "default": ''
          },
          customText7: {
            title: 'Custom text 7',
            description: 'Text to paste when calling termination:insert-custom-text-7',
            type: 'string',
            "default": ''
          },
          customText8: {
            title: 'Custom text 8',
            description: 'Text to paste when calling termination:insert-custom-text-8',
            type: 'string',
            "default": ''
          }
        }
      }
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvaHJpdHdpay8uYXRvbS9wYWNrYWdlcy90ZXJtaW5hdGlvbi9saWIvdGVybWluYXRpb24uY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQUEsTUFBTSxDQUFDLE9BQVAsR0FDRTtJQUFBLFNBQUEsRUFBVyxJQUFYO0lBRUEsUUFBQSxFQUFVLFNBQUEsR0FBQSxDQUZWO0lBSUEsVUFBQSxFQUFZLFNBQUE7QUFDVixVQUFBOztXQUFjLENBQUUsT0FBaEIsQ0FBQTs7YUFDQSxJQUFDLENBQUEsYUFBRCxHQUFpQjtJQUZQLENBSlo7SUFRQSwwQkFBQSxFQUE0QixTQUFBO2FBQzFCO1FBQUEsZ0JBQUEsRUFBa0IsU0FBQyxTQUFEO0FBQ2hCLGNBQUE7QUFBQTtlQUFBLGlCQUFBOzt5QkFDRSxPQUFPLENBQUMsR0FBSSxDQUFBLElBQUEsQ0FBWixHQUFvQjtBQUR0Qjs7UUFEZ0IsQ0FBbEI7UUFHQSxHQUFBLEVBQUssQ0FBQSxTQUFBLEtBQUE7aUJBQUEsU0FBQyxRQUFEO21CQUNILEtBQUMsQ0FBQSxhQUFhLENBQUMsdUJBQWYsQ0FBdUMsUUFBdkM7VUFERztRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FITDtRQUtBLGdCQUFBLEVBQWtCLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUE7bUJBQ2hCLEtBQUMsQ0FBQSxhQUFhLENBQUM7VUFEQztRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FMbEI7UUFPQSxJQUFBLEVBQU0sQ0FBQSxTQUFBLEtBQUE7aUJBQUEsU0FBQTttQkFDSixLQUFDLENBQUEsYUFBYSxDQUFDLGNBQWYsQ0FBQTtVQURJO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQVBOOztJQUQwQixDQVI1QjtJQW1CQSxvQkFBQSxFQUFzQixTQUFBO2FBQ3BCO1FBQUEsR0FBQSxFQUFLLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUMsUUFBRDttQkFDSCxLQUFDLENBQUEsYUFBYSxDQUFDLHVCQUFmLENBQXVDLFFBQXZDO1VBREc7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQUw7UUFFQSxnQkFBQSxFQUFrQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUNoQixLQUFDLENBQUEsYUFBYSxDQUFDO1VBREM7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRmxCOztJQURvQixDQW5CdEI7SUF5QkEsZ0JBQUEsRUFBa0IsU0FBQyxpQkFBRDthQUNoQixJQUFDLENBQUEsYUFBRCxHQUFpQixJQUFJLENBQUMsT0FBQSxDQUFRLGNBQVIsQ0FBRCxDQUFKLENBQTZCLGlCQUE3QjtJQURELENBekJsQjtJQTRCQSxNQUFBLEVBQ0U7TUFBQSxPQUFBLEVBQ0U7UUFBQSxJQUFBLEVBQU0sUUFBTjtRQUNBLEtBQUEsRUFBTyxDQURQO1FBRUEsVUFBQSxFQUNFO1VBQUEsU0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLHdCQUFQO1lBQ0EsV0FBQSxFQUFhLCtDQURiO1lBRUEsSUFBQSxFQUFNLFNBRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLElBSFQ7V0FERjtVQUtBLFFBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxvQkFBUDtZQUNBLFdBQUEsRUFBYSxzR0FEYjtZQUdBLElBQUEsRUFBTSxTQUhOO1lBSUEsQ0FBQSxPQUFBLENBQUEsRUFBUyxJQUpUO1dBTkY7VUFXQSxXQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sY0FBUDtZQUNBLFdBQUEsRUFBYSxzREFEYjtZQUVBLElBQUEsRUFBTSxTQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxJQUhUO1dBWkY7VUFnQkEsZUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLG1CQUFQO1lBQ0EsV0FBQSxFQUFhLHVIQURiO1lBR0EsSUFBQSxFQUFNLFNBSE47WUFJQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLElBSlQ7V0FqQkY7VUFzQkEsWUFBQSxFQUNHO1lBQUEsS0FBQSxFQUFPLGdCQUFQO1lBQ0EsV0FBQSxFQUFhLGtEQURiO1lBRUEsSUFBQSxFQUFNLFNBRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLElBSFQ7V0F2Qkg7VUEyQkMsVUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGFBQVA7WUFDQSxXQUFBLEVBQWEsOEJBRGI7WUFFQSxJQUFBLEVBQU0sU0FGTjtZQUdBLENBQUEsT0FBQSxDQUFBLEVBQVMsSUFIVDtXQTVCSDtVQWdDQSxXQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sY0FBUDtZQUNBLFdBQUEsRUFBYSxxQ0FEYjtZQUVBLElBQUEsRUFBTSxTQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxJQUhUO1dBakNGO1VBcUNBLGlCQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8scUJBQVA7WUFDQSxXQUFBLEVBQWEsbUpBRGI7WUFJQSxJQUFBLEVBQU0sU0FKTjtZQUtBLENBQUEsT0FBQSxDQUFBLEVBQVMsSUFMVDtXQXRDRjtTQUhGO09BREY7TUFnREEsSUFBQSxFQUNFO1FBQUEsSUFBQSxFQUFNLFFBQU47UUFDQSxLQUFBLEVBQU8sQ0FEUDtRQUVBLFVBQUEsRUFDRTtVQUFBLGNBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxrQkFBUDtZQUNBLFdBQUEsRUFBYSw0Q0FEYjtZQUVBLElBQUEsRUFBTSxRQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxFQUhUO1dBREY7VUFLQSxjQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sa0JBQVA7WUFDQSxXQUFBLEVBQWEscUdBRGI7WUFHQSxJQUFBLEVBQU0sUUFITjtZQUlBLENBQUEsT0FBQSxDQUFBLEVBQVMsTUFKVDtZQUtBLENBQUEsSUFBQSxDQUFBLEVBQU0sQ0FBQyxNQUFELEVBQVMsTUFBVCxFQUFpQixRQUFqQixDQUxOO1dBTkY7VUFZQSxzQkFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGlEQUFQO1lBQ0EsV0FBQSxFQUFhLG1IQURiO1lBR0EsSUFBQSxFQUFNLFNBSE47WUFJQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEtBSlQ7V0FiRjtVQWtCQSxVQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sYUFBUDtZQUNBLFdBQUEsRUFBYSwyQ0FEYjtZQUVBLElBQUEsRUFBTSxTQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxJQUhUO1dBbkJGO1VBdUJBLEtBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxnQkFBUDtZQUNBLFdBQUEsRUFBYSxnREFEYjtZQUVBLElBQUEsRUFBTSxRQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBWSxDQUFBLFNBQUE7QUFDVixrQkFBQTtjQUFBLElBQUcsT0FBTyxDQUFDLFFBQVIsS0FBb0IsT0FBdkI7Z0JBQ0UsSUFBQSxHQUFPLE9BQUEsQ0FBUSxNQUFSO3VCQUNQLElBQUksQ0FBQyxPQUFMLENBQWEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUF6QixFQUFxQyxVQUFyQyxFQUFpRCxtQkFBakQsRUFBc0UsTUFBdEUsRUFBOEUsZ0JBQTlFLEVBRkY7ZUFBQSxNQUFBO3VCQUlFLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBWixJQUFxQixZQUp2Qjs7WUFEVSxDQUFBLENBQUgsQ0FBQSxDQUhUO1dBeEJGO1VBaUNBLGNBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxpQkFBUDtZQUNBLFdBQUEsRUFBYSx5REFEYjtZQUVBLElBQUEsRUFBTSxRQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxFQUhUO1dBbENGO1VBc0NBLFFBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyw2QkFBUDtZQUNBLFdBQUEsRUFBYSwwRkFEYjtZQUVBLElBQUEsRUFBTSxRQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxFQUhUO1dBdkNGO1VBMkNBLGdCQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sbUJBQVA7WUFDQSxXQUFBLEVBQWEsc0ZBRGI7WUFHQSxJQUFBLEVBQU0sUUFITjtZQUlBLENBQUEsT0FBQSxDQUFBLEVBQVMsU0FKVDtZQUtBLENBQUEsSUFBQSxDQUFBLEVBQU0sQ0FBQyxNQUFELEVBQVMsU0FBVCxFQUFvQixhQUFwQixDQUxOO1dBNUNGO1NBSEY7T0FqREY7TUFzR0EsS0FBQSxFQUNFO1FBQUEsSUFBQSxFQUFNLFFBQU47UUFDQSxLQUFBLEVBQU8sQ0FEUDtRQUVBLFVBQUEsRUFDRTtVQUFBLGNBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxpQkFBUDtZQUNBLFdBQUEsRUFBYSxzRUFEYjtZQUVBLElBQUEsRUFBTSxRQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxHQUhUO1lBSUEsT0FBQSxFQUFTLEdBSlQ7WUFLQSxPQUFBLEVBQVMsS0FMVDtXQURGO1VBT0EsVUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGFBQVA7WUFDQSxXQUFBLEVBQWEsZ0pBRGI7WUFHQSxJQUFBLEVBQU0sUUFITjtZQUlBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFKVDtXQVJGO1VBYUEsUUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLFdBQVA7WUFDQSxXQUFBLEVBQWEsNkNBRGI7WUFFQSxJQUFBLEVBQU0sUUFGTjtZQUdBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFIVDtXQWRGO1VBa0JBLGtCQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sc0JBQVA7WUFDQSxXQUFBLEVBQWEsZ0ZBRGI7WUFHQSxJQUFBLEVBQU0sUUFITjtZQUlBLENBQUEsT0FBQSxDQUFBLEVBQVMsT0FKVDtXQW5CRjtVQXdCQSxLQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sT0FBUDtZQUNBLFdBQUEsRUFBYSxrQ0FEYjtZQUVBLElBQUEsRUFBTSxRQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxVQUhUO1lBSUEsQ0FBQSxJQUFBLENBQUEsRUFBTSxDQUNKLFVBREksRUFFSixTQUZJLEVBR0osT0FISSxFQUlKLE9BSkksRUFLSixVQUxJLEVBTUosVUFOSSxFQU9KLE9BUEksRUFRSixPQVJJLEVBU0osS0FUSSxFQVVKLEtBVkksRUFXSixXQVhJLEVBWUosZ0JBWkksRUFhSixnQkFiSSxFQWNKLGNBZEksRUFlSixTQWZJLEVBZ0JKLFdBaEJJLEVBaUJKLFFBakJJLEVBa0JKLFVBbEJJLEVBbUJKLFdBbkJJLEVBb0JKLE9BcEJJLEVBcUJKLFNBckJJLENBSk47V0F6QkY7U0FIRjtPQXZHRjtNQThKQSxVQUFBLEVBQ0U7UUFBQSxJQUFBLEVBQU0sUUFBTjtRQUNBLEtBQUEsRUFBTyxDQURQO1FBRUEsVUFBQSxFQUNFO1VBQUEsR0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGlCQUFQO1lBQ0EsV0FBQSxFQUFhLGlDQURiO1lBRUEsSUFBQSxFQUFNLE9BRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEtBSFQ7V0FERjtVQUtBLE1BQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxvQkFBUDtZQUNBLFdBQUEsRUFBYSxvQ0FEYjtZQUVBLElBQUEsRUFBTSxPQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxRQUhUO1dBTkY7VUFVQSxNQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sb0JBQVA7WUFDQSxXQUFBLEVBQWEsb0NBRGI7WUFFQSxJQUFBLEVBQU0sT0FGTjtZQUdBLENBQUEsT0FBQSxDQUFBLEVBQVMsUUFIVDtXQVhGO1VBZUEsS0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLG1CQUFQO1lBQ0EsV0FBQSxFQUFhLG1DQURiO1lBRUEsSUFBQSxFQUFNLE9BRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLE9BSFQ7V0FoQkY7VUFvQkEsSUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGtCQUFQO1lBQ0EsV0FBQSxFQUFhLGtDQURiO1lBRUEsSUFBQSxFQUFNLE9BRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLE1BSFQ7V0FyQkY7VUF5QkEsTUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLG9CQUFQO1lBQ0EsV0FBQSxFQUFhLG9DQURiO1lBRUEsSUFBQSxFQUFNLE9BRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLFFBSFQ7V0ExQkY7VUE4QkEsSUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGtCQUFQO1lBQ0EsV0FBQSxFQUFhLGtDQURiO1lBRUEsSUFBQSxFQUFNLE9BRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLFNBSFQ7V0EvQkY7VUFtQ0EsSUFBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGtCQUFQO1lBQ0EsV0FBQSxFQUFhLGtDQURiO1lBRUEsSUFBQSxFQUFNLE9BRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLE1BSFQ7V0FwQ0Y7VUF3Q0EsT0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLHFCQUFQO1lBQ0EsV0FBQSxFQUFhLHFDQURiO1lBRUEsSUFBQSxFQUFNLE9BRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLFNBSFQ7V0F6Q0Y7U0FIRjtPQS9KRjtNQStNQSxXQUFBLEVBQ0U7UUFBQSxJQUFBLEVBQU0sUUFBTjtRQUNBLEtBQUEsRUFBTyxDQURQO1FBRUEsVUFBQSxFQUNFO1VBQUEsV0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGVBQVA7WUFDQSxXQUFBLEVBQWEsdU5BRGI7WUFJQSxJQUFBLEVBQU0sUUFKTjtZQUtBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFMVDtXQURGO1VBT0EsV0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGVBQVA7WUFDQSxXQUFBLEVBQWEsNkRBRGI7WUFFQSxJQUFBLEVBQU0sUUFGTjtZQUdBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFIVDtXQVJGO1VBWUEsV0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGVBQVA7WUFDQSxXQUFBLEVBQWEsNkRBRGI7WUFFQSxJQUFBLEVBQU0sUUFGTjtZQUdBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFIVDtXQWJGO1VBaUJBLFdBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxlQUFQO1lBQ0EsV0FBQSxFQUFhLDZEQURiO1lBRUEsSUFBQSxFQUFNLFFBRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEVBSFQ7V0FsQkY7VUFzQkEsV0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGVBQVA7WUFDQSxXQUFBLEVBQWEsNkRBRGI7WUFFQSxJQUFBLEVBQU0sUUFGTjtZQUdBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFIVDtXQXZCRjtVQTJCQSxXQUFBLEVBQ0U7WUFBQSxLQUFBLEVBQU8sZUFBUDtZQUNBLFdBQUEsRUFBYSw2REFEYjtZQUVBLElBQUEsRUFBTSxRQUZOO1lBR0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxFQUhUO1dBNUJGO1VBZ0NBLFdBQUEsRUFDRTtZQUFBLEtBQUEsRUFBTyxlQUFQO1lBQ0EsV0FBQSxFQUFhLDZEQURiO1lBRUEsSUFBQSxFQUFNLFFBRk47WUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEVBSFQ7V0FqQ0Y7VUFxQ0EsV0FBQSxFQUNFO1lBQUEsS0FBQSxFQUFPLGVBQVA7WUFDQSxXQUFBLEVBQWEsNkRBRGI7WUFFQSxJQUFBLEVBQU0sUUFGTjtZQUdBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFIVDtXQXRDRjtTQUhGO09BaE5GO0tBN0JGOztBQURGIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPVxuICBzdGF0dXNCYXI6IG51bGxcblxuICBhY3RpdmF0ZTogLT5cblxuICBkZWFjdGl2YXRlOiAtPlxuICAgIEBzdGF0dXNCYXJUaWxlPy5kZXN0cm95KClcbiAgICBAc3RhdHVzQmFyVGlsZSA9IG51bGxcblxuICBwcm92aWRlVGVybWluYXRpb25UZXJtaW5hbDogLT5cbiAgICB1cGRhdGVQcm9jZXNzRW52OiAodmFyaWFibGVzKSAtPlxuICAgICAgZm9yIG5hbWUsIHZhbHVlIG9mIHZhcmlhYmxlc1xuICAgICAgICBwcm9jZXNzLmVudltuYW1lXSA9IHZhbHVlXG4gICAgcnVuOiAoY29tbWFuZHMpID0+XG4gICAgICBAc3RhdHVzQmFyVGlsZS5ydW5Db21tYW5kSW5OZXdUZXJtaW5hbCBjb21tYW5kc1xuICAgIGdldFRlcm1pbmFsVmlld3M6ICgpID0+XG4gICAgICBAc3RhdHVzQmFyVGlsZS50ZXJtaW5hbFZpZXdzXG4gICAgb3BlbjogKCkgPT5cbiAgICAgIEBzdGF0dXNCYXJUaWxlLnJ1bk5ld1Rlcm1pbmFsKClcblxuICBwcm92aWRlUnVuSW5UZXJtaW5hbDogLT5cbiAgICBydW46IChjb21tYW5kcykgPT5cbiAgICAgIEBzdGF0dXNCYXJUaWxlLnJ1bkNvbW1hbmRJbk5ld1Rlcm1pbmFsIGNvbW1hbmRzXG4gICAgZ2V0VGVybWluYWxWaWV3czogKCkgPT5cbiAgICAgIEBzdGF0dXNCYXJUaWxlLnRlcm1pbmFsVmlld3NcblxuICBjb25zdW1lU3RhdHVzQmFyOiAoc3RhdHVzQmFyUHJvdmlkZXIpIC0+XG4gICAgQHN0YXR1c0JhclRpbGUgPSBuZXcgKHJlcXVpcmUgJy4vc3RhdHVzLWJhcicpKHN0YXR1c0JhclByb3ZpZGVyKVxuXG4gIGNvbmZpZzpcbiAgICB0b2dnbGVzOlxuICAgICAgdHlwZTogJ29iamVjdCdcbiAgICAgIG9yZGVyOiAxXG4gICAgICBwcm9wZXJ0aWVzOlxuICAgICAgICBhdXRvQ2xvc2U6XG4gICAgICAgICAgdGl0bGU6ICdDbG9zZSBUZXJtaW5hbCBvbiBFeGl0J1xuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnU2hvdWxkIHRoZSB0ZXJtaW5hbCBjbG9zZSBpZiB0aGUgc2hlbGwgZXhpdHM/J1xuICAgICAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICAgICAgYXV0b05hbWU6XG4gICAgICAgICAgdGl0bGU6ICdBdXRvIE5hbWUgVGVybWluYWwnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdTaG91bGQgdGhlIHRlcm1pbmFsIG5hbWUgaXRzZWxmIGJhc2VkIG9uIHRoZSBkaXJlY3RvcnlcbiAgICAgICAgICBvZiB0aGUgY3VycmVudCBmaWxlIG9wZW4gaW4geW91ciB0ZXh0IGVkaXRvcj8nXG4gICAgICAgICAgdHlwZTogJ2Jvb2xlYW4nXG4gICAgICAgICAgZGVmYXVsdDogdHJ1ZVxuICAgICAgICBjdXJzb3JCbGluazpcbiAgICAgICAgICB0aXRsZTogJ0N1cnNvciBCbGluaydcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1Nob3VsZCB0aGUgY3Vyc29yIGJsaW5rIHdoZW4gdGhlIHRlcm1pbmFsIGlzIGFjdGl2ZT8nXG4gICAgICAgICAgdHlwZTogJ2Jvb2xlYW4nXG4gICAgICAgICAgZGVmYXVsdDogdHJ1ZVxuICAgICAgICBydW5JbnNlcnRlZFRleHQ6XG4gICAgICAgICAgdGl0bGU6ICdSdW4gSW5zZXJ0ZWQgVGV4dCdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1J1biB0ZXh0IGluc2VydGVkIHZpYSBgdGVybWluYXRpb246aW5zZXJ0LXRleHRgIGFzIGFcbiAgICAgICAgICBjb21tYW5kPyAqKlRoaXMgd2lsbCBhcHBlbmQgYW4gZW5kLW9mLWxpbmUgY2hhcmFjdGVyIHRvIGlucHV0LioqJ1xuICAgICAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICAgICAgc2VsZWN0VG9Db3B5OlxuICAgICAgICAgICB0aXRsZTogJ1NlbGVjdCBUbyBDb3B5J1xuICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0NvcGllcyB0ZXh0IHRvIGNsaXBib2FyZCB3aGVuIHNlbGVjdGlvbiBoYXBwZW5zLidcbiAgICAgICAgICAgdHlwZTogJ2Jvb2xlYW4nXG4gICAgICAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICAgICAgIGxvZ2luU2hlbGw6XG4gICAgICAgICAgIHRpdGxlOiAnTG9naW4gU2hlbGwnXG4gICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVXNlIC0tbG9naW4gb24genNoIGFuZCBiYXNoLidcbiAgICAgICAgICAgdHlwZTogJ2Jvb2xlYW4nXG4gICAgICAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICAgICAgc2hvd1Rvb2xiYXI6XG4gICAgICAgICAgdGl0bGU6ICdTaG93IFRvb2xiYXInXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdTaG93IHRvb2xiYXIgYWJvdmUgdGVybWluYWwgd2luZG93LidcbiAgICAgICAgICB0eXBlOiAnYm9vbGVhbidcbiAgICAgICAgICBkZWZhdWx0OiB0cnVlXG4gICAgICAgIGNsb25lVGVybWluYWxQbHVzOlxuICAgICAgICAgIHRpdGxlOiAnQ2xvbmUgVGVybWluYWwtUGx1cydcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1Nob3VsZCB0aGVyZSBiZSBhIGRlZGljYXRlZCBib3R0b20gcGFuZWwgZm9yIHRlcm1pbmF0aW9uP1xuICAgICAgICAgIFRoaXMgd2lsbCBnaXZlIHRlcm1pbmF0aW9uIGEgc2ltaWxhciBhcHBlYXJhbmNlIHRvIHRlcm1pbmFsLXBsdXMuXG4gICAgICAgICAgKipSZXN0YXJ0IFJlcXVpcmVkLioqJ1xuICAgICAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICBjb3JlOlxuICAgICAgdHlwZTogJ29iamVjdCdcbiAgICAgIG9yZGVyOiAyXG4gICAgICBwcm9wZXJ0aWVzOlxuICAgICAgICBhdXRvUnVuQ29tbWFuZDpcbiAgICAgICAgICB0aXRsZTogJ0F1dG8gUnVuIENvbW1hbmQnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdDb21tYW5kIHRvIHJ1biBvbiB0ZXJtaW5hbCBpbml0aWFsaXphdGlvbi4nXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICBtYXBUZXJtaW5hbHNUbzpcbiAgICAgICAgICB0aXRsZTogJ01hcCBUZXJtaW5hbHMgVG8nXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdNYXAgdGVybWluYWxzIHRvIGVhY2ggZmlsZSBvciBmb2xkZXIuIERlZmF1bHQgaXMgbm9cbiAgICAgICAgICBhY3Rpb24gb3IgbWFwcGluZyBhdCBhbGwuICoqUmVzdGFydCByZXF1aXJlZC4qKidcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdOb25lJ1xuICAgICAgICAgIGVudW06IFsnTm9uZScsICdGaWxlJywgJ0ZvbGRlciddXG4gICAgICAgIG1hcFRlcm1pbmFsc1RvQXV0b09wZW46XG4gICAgICAgICAgdGl0bGU6ICdBdXRvIE9wZW4gYSBOZXcgVGVybWluYWwgKEZvciBUZXJtaW5hbCBNYXBwaW5nKSdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1Nob3VsZCBhIG5ldyB0ZXJtaW5hbCBiZSBvcGVuZWQgZm9yIG5ldyBpdGVtcz8gKipOb3RlOioqXG4gICAgICAgICAgIFRoaXMgd29ya3MgaW4gY29uanVuY3Rpb24gd2l0aCBgTWFwIFRlcm1pbmFscyBUb2AgYWJvdmUuJ1xuICAgICAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgICAgIGRlZmF1bHQ6IGZhbHNlXG4gICAgICAgIHNjcm9sbGJhY2s6XG4gICAgICAgICAgdGl0bGU6ICdTY3JvbGwgQmFjaydcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ0hvdyBtYW55IGxpbmVzIG9mIGhpc3Rvcnkgc2hvdWxkIGJlIGtlcHQ/J1xuICAgICAgICAgIHR5cGU6ICdpbnRlZ2VyJ1xuICAgICAgICAgIGRlZmF1bHQ6IDEwMDBcbiAgICAgICAgc2hlbGw6XG4gICAgICAgICAgdGl0bGU6ICdTaGVsbCBPdmVycmlkZSdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ092ZXJyaWRlIHRoZSBkZWZhdWx0IHNoZWxsIGluc3RhbmNlIHRvIGxhdW5jaC4nXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiBkbyAtPlxuICAgICAgICAgICAgaWYgcHJvY2Vzcy5wbGF0Zm9ybSBpcyAnd2luMzInXG4gICAgICAgICAgICAgIHBhdGggPSByZXF1aXJlICdwYXRoJ1xuICAgICAgICAgICAgICBwYXRoLnJlc29sdmUocHJvY2Vzcy5lbnYuU3lzdGVtUm9vdCwgJ1N5c3RlbTMyJywgJ1dpbmRvd3NQb3dlclNoZWxsJywgJ3YxLjAnLCAncG93ZXJzaGVsbC5leGUnKVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICBwcm9jZXNzLmVudi5TSEVMTCB8fCAnL2Jpbi9iYXNoJ1xuICAgICAgICBzaGVsbEFyZ3VtZW50czpcbiAgICAgICAgICB0aXRsZTogJ1NoZWxsIEFyZ3VtZW50cydcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1NwZWNpZnkgc29tZSBhcmd1bWVudHMgdG8gdXNlIHdoZW4gbGF1bmNoaW5nIHRoZSBzaGVsbC4nXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICBzaGVsbEVudjpcbiAgICAgICAgICB0aXRsZTogJ1NoZWxsIEVudmlyb25tZW50IFZhcmlhYmxlcydcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1NwZWNpZnkgc29tZSBhZGRpdGlvbmFsIGVudmlyb25tZW50IHZhcmlhYmxlcywgc3BhY2Ugc2VwYXJhdGVkIHdpdGggdGhlIGZvcm0gYFZBUj1WQUxVRWAnXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICB3b3JraW5nRGlyZWN0b3J5OlxuICAgICAgICAgIHRpdGxlOiAnV29ya2luZyBEaXJlY3RvcnknXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdXaGljaCBkaXJlY3Rvcnkgc2hvdWxkIGJlIHRoZSBwcmVzZW50IHdvcmtpbmcgZGlyZWN0b3J5XG4gICAgICAgICAgd2hlbiBhIG5ldyB0ZXJtaW5hbCBpcyBtYWRlPydcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdQcm9qZWN0J1xuICAgICAgICAgIGVudW06IFsnSG9tZScsICdQcm9qZWN0JywgJ0FjdGl2ZSBGaWxlJ11cbiAgICBzdHlsZTpcbiAgICAgIHR5cGU6ICdvYmplY3QnXG4gICAgICBvcmRlcjogM1xuICAgICAgcHJvcGVydGllczpcbiAgICAgICAgYW5pbWF0aW9uU3BlZWQ6XG4gICAgICAgICAgdGl0bGU6ICdBbmltYXRpb24gU3BlZWQnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdIb3cgZmFzdCBzaG91bGQgdGhlIHdpbmRvdyBhbmltYXRlPyBBIHZhbHVlIG9mIDAgZGlzYWJsZXMgYW5pbWF0aW9uLidcbiAgICAgICAgICB0eXBlOiAnbnVtYmVyJ1xuICAgICAgICAgIGRlZmF1bHQ6ICcxJ1xuICAgICAgICAgIG1pbmltdW06ICcwJ1xuICAgICAgICAgIG1heGltdW06ICcxMDAnXG4gICAgICAgIGZvbnRGYW1pbHk6XG4gICAgICAgICAgdGl0bGU6ICdGb250IEZhbWlseSdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ092ZXJyaWRlIHRoZSB0ZXJtaW5hbFxcJ3MgZGVmYXVsdCBmb250IGZhbWlseS4gKipZb3UgbXVzdFxuICAgICAgICAgICB1c2UgYSBbbW9ub3NwYWNlZCBmb250XShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9MaXN0X29mX3R5cGVmYWNlcyNNb25vc3BhY2UpISoqJ1xuICAgICAgICAgIHR5cGU6ICdzdHJpbmcnXG4gICAgICAgICAgZGVmYXVsdDogJydcbiAgICAgICAgZm9udFNpemU6XG4gICAgICAgICAgdGl0bGU6ICdGb250IFNpemUnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdPdmVycmlkZSB0aGUgdGVybWluYWxcXCdzIGRlZmF1bHQgZm9udCBzaXplLidcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgIGRlZmF1bHQ6ICcnXG4gICAgICAgIGRlZmF1bHRQYW5lbEhlaWdodDpcbiAgICAgICAgICB0aXRsZTogJ0RlZmF1bHQgUGFuZWwgSGVpZ2h0J1xuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnRGVmYXVsdCBoZWlnaHQgb2YgYSB0ZXJtaW5hbCBwYW5lbC4gKipZb3UgbWF5IGVudGVyIGFcbiAgICAgICAgICB2YWx1ZSBpbiBweCwgZW0sIG9yICUuKionXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiAnMzAwcHgnXG4gICAgICAgIHRoZW1lOlxuICAgICAgICAgIHRpdGxlOiAnVGhlbWUnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdTZWxlY3QgYSB0aGVtZSBmb3IgdGhlIHRlcm1pbmFsLidcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdzdGFuZGFyZCdcbiAgICAgICAgICBlbnVtOiBbXG4gICAgICAgICAgICAnc3RhbmRhcmQnLFxuICAgICAgICAgICAgJ2ludmVyc2UnLFxuICAgICAgICAgICAgJ2xpbnV4JyxcbiAgICAgICAgICAgICdncmFzcycsXG4gICAgICAgICAgICAnaG9tZWJyZXcnLFxuICAgICAgICAgICAgJ21hbi1wYWdlJyxcbiAgICAgICAgICAgICdub3ZlbCcsXG4gICAgICAgICAgICAnb2NlYW4nLFxuICAgICAgICAgICAgJ3BybycsXG4gICAgICAgICAgICAncmVkJyxcbiAgICAgICAgICAgICdyZWQtc2FuZHMnLFxuICAgICAgICAgICAgJ3NpbHZlci1hZXJvZ2VsJyxcbiAgICAgICAgICAgICdzb2xhcml6ZWQtZGFyaycsXG4gICAgICAgICAgICAnc29saWQtY29sb3JzJyxcbiAgICAgICAgICAgICdkcmFjdWxhJyxcbiAgICAgICAgICAgICdDaHJpc3RtYXMnLFxuICAgICAgICAgICAgJ2dpdGh1YicsXG4gICAgICAgICAgICAnb25lLWRhcmsnLFxuICAgICAgICAgICAgJ29uZS1saWdodCcsXG4gICAgICAgICAgICAnYmxpc3MnLFxuICAgICAgICAgICAgJ2dydXZib3gnXG4gICAgICAgICAgXVxuICAgIGljb25Db2xvcnM6XG4gICAgICB0eXBlOiAnb2JqZWN0J1xuICAgICAgb3JkZXI6IDVcbiAgICAgIHByb3BlcnRpZXM6XG4gICAgICAgIHJlZDpcbiAgICAgICAgICB0aXRsZTogJ1N0YXR1cyBJY29uIFJlZCdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1JlZCBjb2xvciB1c2VkIGZvciBzdGF0dXMgaWNvbi4nXG4gICAgICAgICAgdHlwZTogJ2NvbG9yJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdyZWQnXG4gICAgICAgIG9yYW5nZTpcbiAgICAgICAgICB0aXRsZTogJ1N0YXR1cyBJY29uIE9yYW5nZSdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ09yYW5nZSBjb2xvciB1c2VkIGZvciBzdGF0dXMgaWNvbi4nXG4gICAgICAgICAgdHlwZTogJ2NvbG9yJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdvcmFuZ2UnXG4gICAgICAgIHllbGxvdzpcbiAgICAgICAgICB0aXRsZTogJ1N0YXR1cyBJY29uIFllbGxvdydcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1llbGxvdyBjb2xvciB1c2VkIGZvciBzdGF0dXMgaWNvbi4nXG4gICAgICAgICAgdHlwZTogJ2NvbG9yJ1xuICAgICAgICAgIGRlZmF1bHQ6ICd5ZWxsb3cnXG4gICAgICAgIGdyZWVuOlxuICAgICAgICAgIHRpdGxlOiAnU3RhdHVzIEljb24gR3JlZW4nXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdHcmVlbiBjb2xvciB1c2VkIGZvciBzdGF0dXMgaWNvbi4nXG4gICAgICAgICAgdHlwZTogJ2NvbG9yJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdncmVlbidcbiAgICAgICAgYmx1ZTpcbiAgICAgICAgICB0aXRsZTogJ1N0YXR1cyBJY29uIEJsdWUnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdCbHVlIGNvbG9yIHVzZWQgZm9yIHN0YXR1cyBpY29uLidcbiAgICAgICAgICB0eXBlOiAnY29sb3InXG4gICAgICAgICAgZGVmYXVsdDogJ2JsdWUnXG4gICAgICAgIHB1cnBsZTpcbiAgICAgICAgICB0aXRsZTogJ1N0YXR1cyBJY29uIFB1cnBsZSdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1B1cnBsZSBjb2xvciB1c2VkIGZvciBzdGF0dXMgaWNvbi4nXG4gICAgICAgICAgdHlwZTogJ2NvbG9yJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdwdXJwbGUnXG4gICAgICAgIHBpbms6XG4gICAgICAgICAgdGl0bGU6ICdTdGF0dXMgSWNvbiBQaW5rJ1xuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnUGluayBjb2xvciB1c2VkIGZvciBzdGF0dXMgaWNvbi4nXG4gICAgICAgICAgdHlwZTogJ2NvbG9yJ1xuICAgICAgICAgIGRlZmF1bHQ6ICdob3RwaW5rJ1xuICAgICAgICBjeWFuOlxuICAgICAgICAgIHRpdGxlOiAnU3RhdHVzIEljb24gQ3lhbidcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ0N5YW4gY29sb3IgdXNlZCBmb3Igc3RhdHVzIGljb24uJ1xuICAgICAgICAgIHR5cGU6ICdjb2xvcidcbiAgICAgICAgICBkZWZhdWx0OiAnY3lhbidcbiAgICAgICAgbWFnZW50YTpcbiAgICAgICAgICB0aXRsZTogJ1N0YXR1cyBJY29uIE1hZ2VudGEnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdNYWdlbnRhIGNvbG9yIHVzZWQgZm9yIHN0YXR1cyBpY29uLidcbiAgICAgICAgICB0eXBlOiAnY29sb3InXG4gICAgICAgICAgZGVmYXVsdDogJ21hZ2VudGEnXG4gICAgY3VzdG9tVGV4dHM6XG4gICAgICB0eXBlOiAnb2JqZWN0J1xuICAgICAgb3JkZXI6IDZcbiAgICAgIHByb3BlcnRpZXM6XG4gICAgICAgIGN1c3RvbVRleHQxOlxuICAgICAgICAgIHRpdGxlOiAnQ3VzdG9tIHRleHQgMSdcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1RleHQgdG8gcGFzdGUgd2hlbiBjYWxsaW5nIHRlcm1pbmF0aW9uOmluc2VydC1jdXN0b20tdGV4dC0xLFxuICAgICAgICAgICRTIGlzIHJlcGxhY2VkIGJ5IHNlbGVjdGlvbiwgJEYgaXMgcmVwbGFjZWQgYnkgZmlsZSBuYW1lLCAkRCBpcyByZXBsYWNlZFxuICAgICAgICAgIGJ5IGZpbGUgZGlyZWN0b3J5LCAkTCBpcyByZXBsYWNlZCBieSBsaW5lIG51bWJlciBvZiBjdXJzb3IsICQkIGlzIHJlcGxhY2VkIGJ5ICQnXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICBjdXN0b21UZXh0MjpcbiAgICAgICAgICB0aXRsZTogJ0N1c3RvbSB0ZXh0IDInXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdUZXh0IHRvIHBhc3RlIHdoZW4gY2FsbGluZyB0ZXJtaW5hdGlvbjppbnNlcnQtY3VzdG9tLXRleHQtMidcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgIGRlZmF1bHQ6ICcnXG4gICAgICAgIGN1c3RvbVRleHQzOlxuICAgICAgICAgIHRpdGxlOiAnQ3VzdG9tIHRleHQgMydcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1RleHQgdG8gcGFzdGUgd2hlbiBjYWxsaW5nIHRlcm1pbmF0aW9uOmluc2VydC1jdXN0b20tdGV4dC0zJ1xuICAgICAgICAgIHR5cGU6ICdzdHJpbmcnXG4gICAgICAgICAgZGVmYXVsdDogJydcbiAgICAgICAgY3VzdG9tVGV4dDQ6XG4gICAgICAgICAgdGl0bGU6ICdDdXN0b20gdGV4dCA0J1xuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGV4dCB0byBwYXN0ZSB3aGVuIGNhbGxpbmcgdGVybWluYXRpb246aW5zZXJ0LWN1c3RvbS10ZXh0LTQnXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICBjdXN0b21UZXh0NTpcbiAgICAgICAgICB0aXRsZTogJ0N1c3RvbSB0ZXh0IDUnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdUZXh0IHRvIHBhc3RlIHdoZW4gY2FsbGluZyB0ZXJtaW5hdGlvbjppbnNlcnQtY3VzdG9tLXRleHQtNSdcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgIGRlZmF1bHQ6ICcnXG4gICAgICAgIGN1c3RvbVRleHQ2OlxuICAgICAgICAgIHRpdGxlOiAnQ3VzdG9tIHRleHQgNidcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1RleHQgdG8gcGFzdGUgd2hlbiBjYWxsaW5nIHRlcm1pbmF0aW9uOmluc2VydC1jdXN0b20tdGV4dC02J1xuICAgICAgICAgIHR5cGU6ICdzdHJpbmcnXG4gICAgICAgICAgZGVmYXVsdDogJydcbiAgICAgICAgY3VzdG9tVGV4dDc6XG4gICAgICAgICAgdGl0bGU6ICdDdXN0b20gdGV4dCA3J1xuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGV4dCB0byBwYXN0ZSB3aGVuIGNhbGxpbmcgdGVybWluYXRpb246aW5zZXJ0LWN1c3RvbS10ZXh0LTcnXG4gICAgICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICBjdXN0b21UZXh0ODpcbiAgICAgICAgICB0aXRsZTogJ0N1c3RvbSB0ZXh0IDgnXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdUZXh0IHRvIHBhc3RlIHdoZW4gY2FsbGluZyB0ZXJtaW5hdGlvbjppbnNlcnQtY3VzdG9tLXRleHQtOCdcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgICAgIGRlZmF1bHQ6ICcnXG4iXX0=
