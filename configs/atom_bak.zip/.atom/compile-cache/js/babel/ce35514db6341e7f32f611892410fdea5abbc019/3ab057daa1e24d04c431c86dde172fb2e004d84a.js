Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _atom = require('atom');

// Atom event handle

var _package = require('./package');

// Our package class

var _lodashDebounce = require('lodash.debounce');

var _lodashDebounce2 = _interopRequireDefault(_lodashDebounce);

'use babel';

var pack = new _package.Package();
var GIT_PLUS_COMMIT_TITLE = 'COMMIT_EDITMSG';
var isActive = true;
var disableOnCommit = true;
var saveDelay = undefined;

exports['default'] = {
  config: {
    delay: {
      title: 'Delay',
      description: 'The amount of milliseconds after a change before editor auto saves',
      type: 'integer',
      'default': 500,
      minimum: 500
    },
    disableOnCommit: {
      title: 'Git Plus: Disable on commit?',
      description: 'If true automatically disables autosave when creating a commit message (Git Plus automatically commits on save)',
      type: 'boolean',
      'default': true
    }
  },

  toggle: function toggle() {
    isActive = !isActive;

    if (isActive) {
      atom.notifications.addInfo('Autosave Onchange Enabled!', {
        text: '',
        dismissable: true
      });
    } else {
      atom.notifications.addInfo('Autosave Onchange Disabled!', {
        text: '',
        dismissable: true
      });
    }
  },

  activate: function activate(state) {
    var _this = this;

    // Events subscribed to in atom's system can be easily cleaned up with a CompositeDisposable
    this.subscriptions = new _atom.CompositeDisposable();
    this.subscriptions.add(atom.commands.add('atom-workspace', {
      'autosave-onchange:toggle': this.toggle
    }), atom.config.onDidChange('autosave-onchange.delay', function (values) {
      console.log('autosave delay changed from ' + values.oldValue + ' to ' + values.newValue);
      saveDelay = values.newValue;
    }), atom.config.onDidChange('autosave-onchange.disableOnCommit', function (values) {
      console.log('Disable on commit has changed: ' + values.newValue);
      disableOnCommit = values.newValue;
    }));

    saveDelay = atom.config.get('autosave-onchange.delay');
    disableOnCommit = atom.config.get('autosave-onchange.disableOnCommit');
    var observeEditors = atom.workspace.observeTextEditors(function (editor) {
      var activeWorkspace = atom.views.getView(editor);

      //TODO: Ensure that this would only occur if git-plus package is enabled...
      if (disableOnCommit && isActive && editor.getTitle() === GIT_PLUS_COMMIT_TITLE) {
        console.log('Disabling autosave until commit screen is open...');
        _this.toggle();
        editor.onDidDestroy(function () {
          console.log('Commit screen closed, enabling autosave...');
          if (!isActive) _this.toggle();
        });
      } else {
        activeWorkspace.addEventListener('autocomplete-plus:cancel', function (e) {
          return pack.onAutoCompleteClose(editor, isActive);
        });

        editor.onDidChangeCursorPosition((0, _lodashDebounce2['default'])(function (ev) {
          return pack.onDidChangeCursorPosition(editor, activeWorkspace, isActive);
        }, saveDelay));
      }
    });

    this.subscriptions.add(observeEditors);
  },

  deactivate: function deactivate() {
    this.subscriptions.dispose();
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2hyaXR3aWsvLmF0b20vcGFja2FnZXMvYXV0b3NhdmUtb25jaGFuZ2UvbGliL2F1dG9zYXZlLW9uY2hhbmdlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztvQkFFb0MsTUFBTTs7Ozt1QkFDbEIsV0FBVzs7Ozs4QkFDZCxpQkFBaUI7Ozs7QUFKdEMsV0FBVyxDQUFDOztBQU1aLElBQU0sSUFBSSxHQUFHLHNCQUFhLENBQUM7QUFDM0IsSUFBTSxxQkFBcUIsR0FBRyxnQkFBZ0IsQ0FBQztBQUMvQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7QUFDcEIsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDO0FBQzNCLElBQUksU0FBUyxZQUFBLENBQUM7O3FCQUVDO0FBQ2IsUUFBTSxFQUFFO0FBQ04sU0FBSyxFQUFFO0FBQ0wsV0FBSyxFQUFFLE9BQU87QUFDZCxpQkFBVyxFQUFFLG9FQUFvRTtBQUNqRixVQUFJLEVBQUUsU0FBUztBQUNmLGlCQUFTLEdBQUc7QUFDWixhQUFPLEVBQUUsR0FBRztLQUNiO0FBQ0QsbUJBQWUsRUFBRTtBQUNmLFdBQUssRUFBRSw4QkFBOEI7QUFDckMsaUJBQVcsRUFBRSxpSEFBaUg7QUFDOUgsVUFBSSxFQUFFLFNBQVM7QUFDZixpQkFBUyxJQUFJO0tBQ2Q7R0FDRjs7QUFFRCxRQUFNLEVBQUEsa0JBQUc7QUFDUCxZQUFRLEdBQUcsQ0FBQyxRQUFRLENBQUM7O0FBRXJCLFFBQUksUUFBUSxFQUFFO0FBQ1osVUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsNEJBQTRCLEVBQUU7QUFDdkQsWUFBSSxFQUFFLEVBQUU7QUFDUixtQkFBVyxFQUFFLElBQUk7T0FDbEIsQ0FBQyxDQUFDO0tBQ0osTUFBTTtBQUNMLFVBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLDZCQUE2QixFQUFFO0FBQ3hELFlBQUksRUFBRSxFQUFFO0FBQ1IsbUJBQVcsRUFBRSxJQUFJO09BQ2xCLENBQUMsQ0FBQztLQUNKO0dBQ0Y7O0FBRUQsVUFBUSxFQUFBLGtCQUFDLEtBQUssRUFBRTs7OztBQUVkLFFBQUksQ0FBQyxhQUFhLEdBQUcsK0JBQXlCLENBQUM7QUFDL0MsUUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQ3BCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFO0FBQ2xDLGdDQUEwQixFQUFFLElBQUksQ0FBQyxNQUFNO0tBQ3hDLENBQUMsRUFDRixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyx5QkFBeUIsRUFBRSxVQUFDLE1BQU0sRUFBSztBQUM3RCxhQUFPLENBQUMsR0FBRyxrQ0FBZ0MsTUFBTSxDQUFDLFFBQVEsWUFBTyxNQUFNLENBQUMsUUFBUSxDQUFHLENBQUM7QUFDcEYsZUFBUyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7S0FDN0IsQ0FBQyxFQUNGLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLG1DQUFtQyxFQUFFLFVBQUMsTUFBTSxFQUFLO0FBQ3ZFLGFBQU8sQ0FBQyxHQUFHLHFDQUFtQyxNQUFNLENBQUMsUUFBUSxDQUFHLENBQUM7QUFDakUscUJBQWUsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDO0tBQ25DLENBQUMsQ0FDSCxDQUFDOztBQUVGLGFBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQ3ZELG1CQUFlLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQztBQUN2RSxRQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLFVBQUMsTUFBTSxFQUFLO0FBQ2pFLFVBQUksZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzs7QUFHakQsVUFBSSxlQUFlLElBQUksUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLEVBQUUsS0FBSyxxQkFBcUIsRUFBRTtBQUM5RSxlQUFPLENBQUMsR0FBRyxDQUFDLG1EQUFtRCxDQUFDLENBQUM7QUFDakUsY0FBSyxNQUFNLEVBQUUsQ0FBQztBQUNkLGNBQU0sQ0FBQyxZQUFZLENBQUMsWUFBTTtBQUN4QixpQkFBTyxDQUFDLEdBQUcsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO0FBQzFELGNBQUcsQ0FBQyxRQUFRLEVBQUUsTUFBSyxNQUFNLEVBQUUsQ0FBQztTQUM3QixDQUFDLENBQUM7T0FDSixNQUFNO0FBQ0wsdUJBQWUsQ0FBQyxnQkFBZ0IsQ0FBQywwQkFBMEIsRUFBRSxVQUFDLENBQUM7aUJBQzdELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDO1NBQUEsQ0FBQyxDQUFDOztBQUU5QyxjQUFNLENBQUMseUJBQXlCLENBQzlCLGlDQUFTLFVBQUMsRUFBRTtpQkFDVixJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxFQUFFLGVBQWUsRUFBRSxRQUFRLENBQUM7U0FBQSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7T0FDcEY7S0FDRixDQUFDLENBQUM7O0FBRUgsUUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7R0FDeEM7O0FBRUQsWUFBVSxFQUFBLHNCQUFHO0FBQ1gsUUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztHQUM5QjtDQUNGIiwiZmlsZSI6Ii9ob21lL2hyaXR3aWsvLmF0b20vcGFja2FnZXMvYXV0b3NhdmUtb25jaGFuZ2UvbGliL2F1dG9zYXZlLW9uY2hhbmdlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCc7XG5cbmltcG9ydCB7IENvbXBvc2l0ZURpc3Bvc2FibGUgfSBmcm9tICdhdG9tJzsgLy8gQXRvbSBldmVudCBoYW5kbGVcbmltcG9ydCB7IFBhY2thZ2UgfSBmcm9tICcuL3BhY2thZ2UnOyAvLyBPdXIgcGFja2FnZSBjbGFzc1xuaW1wb3J0IGRlYm91bmNlIGZyb20gJ2xvZGFzaC5kZWJvdW5jZSc7XG5cbmNvbnN0IHBhY2sgPSBuZXcgUGFja2FnZSgpO1xuY29uc3QgR0lUX1BMVVNfQ09NTUlUX1RJVExFID0gJ0NPTU1JVF9FRElUTVNHJztcbmxldCBpc0FjdGl2ZSA9IHRydWU7XG5sZXQgZGlzYWJsZU9uQ29tbWl0ID0gdHJ1ZTtcbmxldCBzYXZlRGVsYXk7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgY29uZmlnOiB7XG4gICAgZGVsYXk6IHtcbiAgICAgIHRpdGxlOiAnRGVsYXknLFxuICAgICAgZGVzY3JpcHRpb246ICdUaGUgYW1vdW50IG9mIG1pbGxpc2Vjb25kcyBhZnRlciBhIGNoYW5nZSBiZWZvcmUgZWRpdG9yIGF1dG8gc2F2ZXMnLFxuICAgICAgdHlwZTogJ2ludGVnZXInLFxuICAgICAgZGVmYXVsdDogNTAwLFxuICAgICAgbWluaW11bTogNTAwXG4gICAgfSxcbiAgICBkaXNhYmxlT25Db21taXQ6IHtcbiAgICAgIHRpdGxlOiAnR2l0IFBsdXM6IERpc2FibGUgb24gY29tbWl0PycsXG4gICAgICBkZXNjcmlwdGlvbjogJ0lmIHRydWUgYXV0b21hdGljYWxseSBkaXNhYmxlcyBhdXRvc2F2ZSB3aGVuIGNyZWF0aW5nIGEgY29tbWl0IG1lc3NhZ2UgKEdpdCBQbHVzIGF1dG9tYXRpY2FsbHkgY29tbWl0cyBvbiBzYXZlKScsXG4gICAgICB0eXBlOiAnYm9vbGVhbicsXG4gICAgICBkZWZhdWx0OiB0cnVlXG4gICAgfVxuICB9LFxuXG4gIHRvZ2dsZSgpIHtcbiAgICBpc0FjdGl2ZSA9ICFpc0FjdGl2ZTtcblxuICAgIGlmIChpc0FjdGl2ZSkge1xuICAgICAgYXRvbS5ub3RpZmljYXRpb25zLmFkZEluZm8oJ0F1dG9zYXZlIE9uY2hhbmdlIEVuYWJsZWQhJywge1xuICAgICAgICB0ZXh0OiAnJyxcbiAgICAgICAgZGlzbWlzc2FibGU6IHRydWVcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhdG9tLm5vdGlmaWNhdGlvbnMuYWRkSW5mbygnQXV0b3NhdmUgT25jaGFuZ2UgRGlzYWJsZWQhJywge1xuICAgICAgICB0ZXh0OiAnJyxcbiAgICAgICAgZGlzbWlzc2FibGU6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgfSxcblxuICBhY3RpdmF0ZShzdGF0ZSkge1xuICAgIC8vIEV2ZW50cyBzdWJzY3JpYmVkIHRvIGluIGF0b20ncyBzeXN0ZW0gY2FuIGJlIGVhc2lseSBjbGVhbmVkIHVwIHdpdGggYSBDb21wb3NpdGVEaXNwb3NhYmxlXG4gICAgdGhpcy5zdWJzY3JpcHRpb25zID0gbmV3IENvbXBvc2l0ZURpc3Bvc2FibGUoKTtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMuYWRkKFxuICAgICAgYXRvbS5jb21tYW5kcy5hZGQoJ2F0b20td29ya3NwYWNlJywge1xuICAgICAgICAnYXV0b3NhdmUtb25jaGFuZ2U6dG9nZ2xlJzogdGhpcy50b2dnbGVcbiAgICAgIH0pLFxuICAgICAgYXRvbS5jb25maWcub25EaWRDaGFuZ2UoJ2F1dG9zYXZlLW9uY2hhbmdlLmRlbGF5JywgKHZhbHVlcykgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhgYXV0b3NhdmUgZGVsYXkgY2hhbmdlZCBmcm9tICR7dmFsdWVzLm9sZFZhbHVlfSB0byAke3ZhbHVlcy5uZXdWYWx1ZX1gKTtcbiAgICAgICAgc2F2ZURlbGF5ID0gdmFsdWVzLm5ld1ZhbHVlO1xuICAgICAgfSksXG4gICAgICBhdG9tLmNvbmZpZy5vbkRpZENoYW5nZSgnYXV0b3NhdmUtb25jaGFuZ2UuZGlzYWJsZU9uQ29tbWl0JywgKHZhbHVlcykgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhgRGlzYWJsZSBvbiBjb21taXQgaGFzIGNoYW5nZWQ6ICR7dmFsdWVzLm5ld1ZhbHVlfWApO1xuICAgICAgICBkaXNhYmxlT25Db21taXQgPSB2YWx1ZXMubmV3VmFsdWU7XG4gICAgICB9KVxuICAgICk7XG5cbiAgICBzYXZlRGVsYXkgPSBhdG9tLmNvbmZpZy5nZXQoJ2F1dG9zYXZlLW9uY2hhbmdlLmRlbGF5Jyk7XG4gICAgZGlzYWJsZU9uQ29tbWl0ID0gYXRvbS5jb25maWcuZ2V0KCdhdXRvc2F2ZS1vbmNoYW5nZS5kaXNhYmxlT25Db21taXQnKTtcbiAgICBsZXQgb2JzZXJ2ZUVkaXRvcnMgPSBhdG9tLndvcmtzcGFjZS5vYnNlcnZlVGV4dEVkaXRvcnMoKGVkaXRvcikgPT4ge1xuICAgICAgbGV0IGFjdGl2ZVdvcmtzcGFjZSA9IGF0b20udmlld3MuZ2V0VmlldyhlZGl0b3IpO1xuXG4gICAgICAvL1RPRE86IEVuc3VyZSB0aGF0IHRoaXMgd291bGQgb25seSBvY2N1ciBpZiBnaXQtcGx1cyBwYWNrYWdlIGlzIGVuYWJsZWQuLi5cbiAgICAgIGlmIChkaXNhYmxlT25Db21taXQgJiYgaXNBY3RpdmUgJiYgZWRpdG9yLmdldFRpdGxlKCkgPT09IEdJVF9QTFVTX0NPTU1JVF9USVRMRSkge1xuICAgICAgICBjb25zb2xlLmxvZygnRGlzYWJsaW5nIGF1dG9zYXZlIHVudGlsIGNvbW1pdCBzY3JlZW4gaXMgb3Blbi4uLicpO1xuICAgICAgICB0aGlzLnRvZ2dsZSgpO1xuICAgICAgICBlZGl0b3Iub25EaWREZXN0cm95KCgpID0+IHtcbiAgICAgICAgICBjb25zb2xlLmxvZygnQ29tbWl0IHNjcmVlbiBjbG9zZWQsIGVuYWJsaW5nIGF1dG9zYXZlLi4uJyk7XG4gICAgICAgICAgaWYoIWlzQWN0aXZlKSB0aGlzLnRvZ2dsZSgpO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFjdGl2ZVdvcmtzcGFjZS5hZGRFdmVudExpc3RlbmVyKCdhdXRvY29tcGxldGUtcGx1czpjYW5jZWwnLCAoZSkgPT5cbiAgICAgICAgICBwYWNrLm9uQXV0b0NvbXBsZXRlQ2xvc2UoZWRpdG9yLCBpc0FjdGl2ZSkpO1xuXG4gICAgICAgIGVkaXRvci5vbkRpZENoYW5nZUN1cnNvclBvc2l0aW9uKFxuICAgICAgICAgIGRlYm91bmNlKChldikgPT5cbiAgICAgICAgICAgIHBhY2sub25EaWRDaGFuZ2VDdXJzb3JQb3NpdGlvbihlZGl0b3IsIGFjdGl2ZVdvcmtzcGFjZSwgaXNBY3RpdmUpLCBzYXZlRGVsYXkpKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHRoaXMuc3Vic2NyaXB0aW9ucy5hZGQob2JzZXJ2ZUVkaXRvcnMpO1xuICB9LFxuXG4gIGRlYWN0aXZhdGUoKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb25zLmRpc3Bvc2UoKTtcbiAgfVxufTtcbiJdfQ==