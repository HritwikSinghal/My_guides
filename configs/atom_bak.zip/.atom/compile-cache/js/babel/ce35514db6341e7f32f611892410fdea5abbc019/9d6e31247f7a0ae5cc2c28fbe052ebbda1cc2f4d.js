'use babel';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var Package = (function () {
  function Package() {
    _classCallCheck(this, Package);
  }

  _createClass(Package, [{
    key: 'onDidChangeCursorPosition',
    value: function onDidChangeCursorPosition(editor, workspace, isActive) {
      if (this._shouldSave(editor) && !this._autocompleteTriggered(workspace) && isActive) this.trigger(editor);
    }
  }, {
    key: 'onDidStopChanging',
    value: function onDidStopChanging(editor, workspace) {
      if (this._shouldSave(editor) && !this._autocompleteTriggered(workspace)) this.trigger(editor);
    }
  }, {
    key: 'onAutoCompleteClose',
    value: function onAutoCompleteClose(editor, isActive) {
      if (this._shouldSave(editor) && isActive) this.trigger(editor);
    }
  }, {
    key: 'trigger',
    value: function trigger(editor) {
      Promise.resolve(editor.save()).then(function () {
        return console.log('Saved');
      })['catch'](function (error) {
        return console.log(error);
      });
    }
  }, {
    key: '_shouldSave',
    value: function _shouldSave(editor) {
      return editor.isModified() && editor.getPath() ? true : false;
    }
  }, {
    key: '_autocompleteTriggered',
    value: function _autocompleteTriggered(workspace) {
      return workspace.querySelector('.autocomplete-plus') ? true : false;
    }
  }]);

  return Package;
})();

exports.Package = Package;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2hyaXR3aWsvLmF0b20vcGFja2FnZXMvYXV0b3NhdmUtb25jaGFuZ2UvbGliL3BhY2thZ2UuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsV0FBVyxDQUFDOzs7Ozs7Ozs7O0lBRU4sT0FBTztBQUVBLFdBRlAsT0FBTyxHQUVHOzBCQUZWLE9BQU87R0FFSzs7ZUFGWixPQUFPOztXQUljLG1DQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO0FBQ3JELFVBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxRQUFRLEVBQ2pGLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDeEI7OztXQUVnQiwyQkFBQyxNQUFNLEVBQUUsU0FBUyxFQUFFO0FBQ25DLFVBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsRUFDckUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUN4Qjs7O1dBRWtCLDZCQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUU7QUFDcEMsVUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLFFBQVEsRUFDdEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUN4Qjs7O1dBRU0saUJBQUMsTUFBTSxFQUFFO0FBQ2QsYUFBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FDM0IsSUFBSSxDQUFDO2VBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7T0FBQSxDQUFDLFNBQzNCLENBQUMsVUFBQyxLQUFLO2VBQUssT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7T0FBQSxDQUFDLENBQUM7S0FDekM7OztXQUVVLHFCQUFDLE1BQU0sRUFBRTtBQUNsQixhQUFPLEFBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUUsR0FBSSxJQUFJLEdBQUcsS0FBSyxDQUFDO0tBQ2pFOzs7V0FFcUIsZ0NBQUMsU0FBUyxFQUFFO0FBQ2hDLGFBQU8sU0FBUyxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLElBQUksR0FBRyxLQUFLLENBQUM7S0FDckU7OztTQS9CRyxPQUFPOzs7UUFtQ1gsT0FBTyxHQUFQLE9BQU8iLCJmaWxlIjoiL2hvbWUvaHJpdHdpay8uYXRvbS9wYWNrYWdlcy9hdXRvc2F2ZS1vbmNoYW5nZS9saWIvcGFja2FnZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnO1xuXG5jbGFzcyBQYWNrYWdlIHtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgb25EaWRDaGFuZ2VDdXJzb3JQb3NpdGlvbihlZGl0b3IsIHdvcmtzcGFjZSwgaXNBY3RpdmUpIHtcbiAgICBpZiAodGhpcy5fc2hvdWxkU2F2ZShlZGl0b3IpICYmICF0aGlzLl9hdXRvY29tcGxldGVUcmlnZ2VyZWQod29ya3NwYWNlKSAmJiBpc0FjdGl2ZSlcbiAgICAgIHRoaXMudHJpZ2dlcihlZGl0b3IpO1xuICB9XG5cbiAgb25EaWRTdG9wQ2hhbmdpbmcoZWRpdG9yLCB3b3Jrc3BhY2UpIHtcbiAgICBpZiAodGhpcy5fc2hvdWxkU2F2ZShlZGl0b3IpICYmICF0aGlzLl9hdXRvY29tcGxldGVUcmlnZ2VyZWQod29ya3NwYWNlKSlcbiAgICAgIHRoaXMudHJpZ2dlcihlZGl0b3IpO1xuICB9XG5cbiAgb25BdXRvQ29tcGxldGVDbG9zZShlZGl0b3IsIGlzQWN0aXZlKSB7XG4gICAgaWYgKHRoaXMuX3Nob3VsZFNhdmUoZWRpdG9yKSAmJiBpc0FjdGl2ZSlcbiAgICAgIHRoaXMudHJpZ2dlcihlZGl0b3IpO1xuICB9XG5cbiAgdHJpZ2dlcihlZGl0b3IpIHtcbiAgICBQcm9taXNlLnJlc29sdmUoZWRpdG9yLnNhdmUoKSlcbiAgICAgIC50aGVuKCgpID0+IGNvbnNvbGUubG9nKCdTYXZlZCcpKVxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gY29uc29sZS5sb2coZXJyb3IpKTtcbiAgfVxuXG4gIF9zaG91bGRTYXZlKGVkaXRvcikge1xuICAgIHJldHVybiAoZWRpdG9yLmlzTW9kaWZpZWQoKSAmJiBlZGl0b3IuZ2V0UGF0aCgpKSA/IHRydWUgOiBmYWxzZTtcbiAgfVxuXG4gIF9hdXRvY29tcGxldGVUcmlnZ2VyZWQod29ya3NwYWNlKSB7XG4gICAgcmV0dXJuIHdvcmtzcGFjZS5xdWVyeVNlbGVjdG9yKCcuYXV0b2NvbXBsZXRlLXBsdXMnKSA/IHRydWUgOiBmYWxzZTtcbiAgfVxufVxuXG5leHBvcnQge1xuICBQYWNrYWdlXG59O1xuIl19