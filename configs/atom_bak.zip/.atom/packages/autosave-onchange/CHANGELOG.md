## 0.1.0 - First Release
* Every feature added
* Every bug fixed

## 1.3.1 - New Maintainer
* Chexwarrior is the new Maintainer (thanks isthatcentered for all your help!)
* Delay before autosave is configurable in package settings
* Key combo ctrl + alt + o toggles autosave functionality

## 1.4
* Autosave automatically disables when Git Plus commit screen loads (Git Plus completes a commit on save so this can be annoying when using both packages). This is configurable within the package settings.
