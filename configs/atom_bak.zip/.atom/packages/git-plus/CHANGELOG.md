## Changelog

### 8.7.1

- Merge [#796](https://github.com/akonwi/git-plus/issues/796) to fix command label for 'Fetch All'
- Hopefully fix [#786](https://github.com/akonwi/git-plus/issues/786)

### 8.7.0

- Merge [#794](https://github.com/akonwi/git-plus/issues/794)
  - New command, 'Delete Branch (Local and Remote)'
- Fix [#791](https://github.com/akonwi/git-plus/issues/791)

### 8.6.3

- Fix [#783](https://github.com/akonwi/git-plus/issues/783)

### 8.6.1

- Fix [#781](https://github.com/akonwi/git-plus/issues/781)

### 8.6.0

- Show current branch next to the repo root in the tree view.
  - This can be disabled in the general settings of the plugin.
  - ![screenshot](https://dl.dropboxusercontent.com/s/bt3lbsd9oxqhhbh//tree-view-branch.png.png)

### 8.5.0

- Render emojis in commit messages. [#780](https://github.com/akonwi/git-plus/issues/780)

### 8.4.2

- Fix for a window creating 2 output views at startup

### 8.4.1

- Fix [#776](https://github.com/akonwi/git-plus/issues/776)

### 8.4.0

- Show notifications for command errors if 'Always show result output' is disabled.
- If the output view is destroyed, it can be recreated via the toggle with restored state.
- Fixes some deserialization bugs with the output view.

### 8.3.0

- Fix [#774](https://github.com/akonwi/git-plus/issues/774). Brings back clicking on the branch name in status bar to activate the Checkout branch command.
- The tree view context menu has been improved to only show commands that are applicable to the selected items. Unfortunately, the current api has no way of knowing if the directory root is a git repository, so there will be git options for non git directories.

### 8.2.1

- Fix issue with git plus hijacking copy/paste commands

### 8.2.0

- bump minimum required atom version to 1.28
- Address [#758](https://github.com/akonwi/git-plus/issues/758)
  - Show command log and output in chronologically descending order. (most recent first)
  - The 'Always show result output' config being enabled will also automatically expand the output of the last command

### 8.1.0

- The output view has been overhauled so it's now more of a log of commands executed.
  - Entries with the settings icon (...) are clickable to toggle the command output
  - Failures will be colored red
  - This view can be dragged and moved into different docks or into main workspace
  - Urls in this view are now clickable and copy-able [#586](https://github.com/akonwi/git-plus/issues/586)

### 8.0.2

- Fixes [#735](https://github.com/akonwi/git-plus/issues/735) to support showing diffs while using the experimental tree sitter grammars

### 8.0.1

- minor bug fix

### 8.0.0

- Removes the default keybindings for commands (except for the menu). You can add them to your local keymapping configuration by copying them from [here](https://github.com/akonwi/git-plus/blob/master/keymaps/git-plus.cson) [#415](https://github.com/akonwi/git-plus/issues/415) [#688](https://github.com/akonwi/git-plus/issues/688)
- Introduces new option to always open the dock to show results (@brycefranzen)[#746](https://github.com/akonwi/git-plus/pull/746)
- `Stage Files`, which was experimental, is now the main command to manage your index and replaces the two commands, `Stage File` + `Unstage File`.
- The split-diff option is now a core setting

### 7.12.0

- Adds new feature `Manage Stashes` to address [#218](https://github.com/akonwi/git-plus/issues/218)
  - This will show your stashes and allow operating specific ones out of stack order.

### 7.11.0

- Merge [#739](https://github.com/akonwi/git-plus/pull/739) to fix #738 (@jdanbrown)

### 7.10.2

- Merge [#719](https://github.com/akonwi/git-plus/pull/719) to fix #681 and #710 (@Fryuni)
- Merge [#728](https://github.com/akonwi/git-plus/pull/728) to fix #717 (@ccjmne)
- Fix [#732](https://github.com/akonwi/git-plus/pull/732) (@ocoka)

### 7.10.0

- Introduces a new option to pull with the '--autostash' flag thanks to (@Fryuni)[#707](https://github.com/akonwi/git-plus/pull/707)
- Changes misspelling of 'branch' in the submenu (@j4cobgarby)[#708](https://github.com/akonwi/git-plus/pull/708)

### 7.9.3

- Fixes [#677](https://github.com/akonwi/git-plus/pull/677)

### 7.9.2

- Fixes [#666](https://github.com/akonwi/git-plus/pull/666)

### 7.9.1

- Fixes [#663](https://github.com/akonwi/git-plus/pull/663)

### 7.9.0

- The output view above the status-bar has been incorporated into the docks of atom v1.17.0
  - The timeout setting for this has also been removed since this is no longer just a notification

### 7.8.1

- Fixes git+ commands not showing up in tree-view context menu
  on atom v1.17.0 [#664](https://github.com/akonwi/git-plus/pull/664) (@pixilz)

### 7.8.0

- Fixes [#654](https://github.com/akonwi/git-plus/issues/654)
- Fixes [#655](https://github.com/akonwi/git-plus/issues/655)

### 7.7.0

- Merge [#653](https://github.com/akonwi/git-plus/pull/653) (@jgnagy)
  - Adds a new config in 'Tags' section to sign tags with GPG

### 7.6.0

- Merge [#648](https://github.com/akonwi/git-plus/pull/648) (@ios122), Which allows executing context actions on the git root path of tree-view
- Update README with details of list views that allow selecting multiple options

### 7.5.0

- Bug fix where trying to pull from a non-existent upstream branch threw an error
- Merge [#634](https://github.com/akonwi/git-plus/pull/634) (@danielbayley), Which allows using right click or a modifier key
  to open the new branch command by clicking on the branch name in the status-bar
- Fix [#633](@oppin)

### 7.4.0

- Adds a new command (`Fetch all`), thanks to @danielbayley
  - [Experimental] Setting for auto fetching the currently open repos
- Fixed bug where atom's git highlighting in the tree-view and branch in the status bar didn't change after custom commands ran

### 7.3.3

- Fixed [#631](https://github.com/akonwi/git-plus/issues/631)

### 7.3.2

- Fixed [#627](https://github.com/akonwi/git-plus/issues/627)
- Removed `Pull using rebase` command from the packages menu in OS status bar
- The `run` function for custom commands now returns a promise that resolves with the git output. Which allows for chaining for more complicated commands.

### 7.3.1

- Fixes [#626](https://github.com/akonwi/git-plus/issues/626)
- Change location of the split-diff generated file
- Removed some dependencies

### 7.3.0

- [Experimental Features] Show diffs between branches (@yacut)
- [Experimental Features] Use the split-diff package to show diffs for a single file (@yacut)

### 7.2.2

- Remove the git+ logo from status-bar when there is no git project in workspace and add it when there is a git project [#613](https://github.com/akonwi/git-plus/issues/613)
- Fixes [#614](https://github.com/akonwi/git-plus/issues/614)

### 7.2.1

- Swapped pin icon in the status-bar for 'git+'. [#613](https://github.com/akonwi/git-plus/issues/613)
- Removed analytics

### 7.2.0

- Fixes [#596](https://github.com/akonwi/git-plus/issues/596)
  - **BREAKING** the config option of `Pull From Upstream` is now the default behavior.
  - If your git config for 'push.default' is set to nothing or you want to intentionally choose a branch, turn on the 'Prompt for branch...' option
- Merges [#604](https://github.com/akonwi/git-plus/issues/604) thanks to (@lgeiger)

### 7.1.1

- Fixes [#598](https://github.com/akonwi/git-plus/issues/598)
- Fixes [#599](https://github.com/akonwi/git-plus/issues/599)

### 7.1.0

- Fixes [#573](https://github.com/akonwi/git-plus/issues/573)

### 7.0.7

- [[#587]](https://github.com/akonwi/git-plus/issues/587) - Refactoring around tree-view context actions

### 7.0.6

- [[#584]](https://github.com/akonwi/git-plus/issues/584)-The COMMIT_EDITMSG file is kept after commit attempts so in case of failure the previously typed message is easily retrievable
- Fixes [#591](https://github.com/akonwi/git-plus/issues/591)
- Fixes [#593](https://github.com/akonwi/git-plus/issues/593)

### 7.0.5

- [[#587]](https://github.com/akonwi/git-plus/issues/587) Gracefully handle unavailable repo error
- Fixes [#578](https://github.com/akonwi/git-plus/issues/578)

### 7.0.4

- Minor changes

### 7.0.3

- More fixes for [#582](https://github.com/akonwi/git-plus/issues/582)

### 7.0.2

- Fixes config issue where none of the non-general configs were being used

### 7.0.1

- Fixes [#582](https://github.com/akonwi/git-plus/issues/582)

### 7.0.0

- Refactored package settings. This update will reset your configurations for this package as the config options have been refactored.
- Add analytics to track which features are being used.

### 6.4.0

- Introducing Custom Commands. This is an experimental feature to allow users to define their own commonly used commands. Read about [them](https://github.com/akonwi/git-plus#experimental-features)

### 6.3.0

- Fixes [#395](https://github.com/akonwi/git-plus/issues/395)
- Fixes [#408](https://github.com/akonwi/git-plus/issues/408)

### 6.2.0

- Introduce new setting 'Stage Files Beta', to combine the 'Stage Files' and 'Unstage Files' commands into a single command.

### 6.0.2

- Fixes [#579](https://github.com/akonwi/git-plus/issues/579)

### 6.0.1

- Fixes [#576](https://github.com/akonwi/git-plus/issues/576)

### 6.0.0

- **BREAKING** The configuration option of 'Pull Before Push' is now a simple toggle and there is a second option 'Pull Rebase', which is also a toggle for whether to do all pulls with the `--rebase` flag.
- Fixes [#235](https://github.com/akonwi/git-plus/issues/235)
- Fixes [#576](https://github.com/akonwi/git-plus/issues/576)
- Remove the experimental tag from the 'Verbose Commits' feature
- Only show the `Init` command in the atom palette when there is no repo in the project

### 5.29.1

- Fixes [#568](https://github.com/akonwi/git-plus/issues/568)
- Fixes [#405](https://github.com/akonwi/git-plus/issues/405)

### 5.29.0

- Fixes [#531](https://github.com/akonwi/git-plus/issues/531)
- Fixes [#292](https://github.com/akonwi/git-plus/issues/292)
- Remove the experimental tag from the 'Always pull from upstream' feature

### 5.28.0

- Display keyboard shortcuts for the commands in the Git Plus menu (@metatalker-[pr-566](https://github.com/akonwi/git-plus/pull/566))

### 5.27.0

- Added more commands to the tree-view context-menu
  - `Add`, `Add + commit`, `Diff`, `Unstage`, `Checkout`

### 5.25.5

- Fix [#553](https://github.com/akonwi/git-plus/issues/553)
- Refactoring

### 5.25.4

- Show error when attempting to push to pull from non-existent upstream branch.

### 5.25.3

- Fix [#548](https://github.com/akonwi/git-plus/issues/548)

### 5.25.2

- Fix [#545](https://github.com/akonwi/git-plus/issues/545)

### 5.25.1

- Use experimental toggle: 'Always Pull From Upstream', when pulling before pushing is enabled

### 5.25.0

- Adds new experimental toggle: 'Always Pull From Upstream', which will pull from your current branch upstream automatically without prompting you for a branch to pull from.
- Fix [#538](https://github.com/akonwi/git-plus/issues/538)
  - [#537](https://github.com/akonwi/git-plus/issues/537) has been left open as the original.

### 5.24.2

- Fix [#436](https://github.com/akonwi/git-plus/issues/436)
- Fix [#529](https://github.com/akonwi/git-plus/issues/529)

### 5.24.1

- Fix [#515](https://github.com/akonwi/git-plus/issues/515)
- Fix [#533](https://github.com/akonwi/git-plus/issues/533)

### 5.25.4

- Show error when attempting to push to pull from non-existent upstream branch.

### 5.25.3

- Fix [#548](https://github.com/akonwi/git-plus/issues/548)

### 5.25.2

- Fix [#545](https://github.com/akonwi/git-plus/issues/545)

### 5.25.1

- Use experimental toggle: 'Always Pull From Upstream', when pulling before pushing is enabled

### 5.25.0

- Adds new experimental toggle: 'Always Pull From Upstream', which will pull from your current branch upstream automatically without prompting you for a branch to pull from.
- Fix [#538](https://github.com/akonwi/git-plus/issues/538)
  - [#537](https://github.com/akonwi/git-plus/issues/537) has been left open as the original.

### 5.24.2

- Fix [#436](https://github.com/akonwi/git-plus/issues/436)
- Fix [#529](https://github.com/akonwi/git-plus/issues/529)

### 5.24.1

- Fix [#515](https://github.com/akonwi/git-plus/issues/515)
- Fix [#533](https://github.com/akonwi/git-plus/issues/533)

### 5.24.0

- This enables basic support for submodules. You should be able to add, commit, and diff files that belong to submodules.
- Small performance improvements for initial loading of the package's command palette.

### 5.23.3

- Add new command, `Commit All and Push`
- Fix [#509](https://github.com/akonwi/git-plus/issues/509) where multiple selected commits weren't being cherry picked.
- Update README
  - Table of commands contains info about using Tags.
  - Add note for Windows users to check out [#224](https://github.com/akonwi/git-plus/issues/224) for troubleshooting pull/push problems

### 5.23.2

- Fix #459 [pr #459](https://github.com/akonwi/git-plus/issues/459)
  - Output from commands executed by Git Run will be colored if git provides coloring

### 5.22.1

- Fix #448 [pr #514](https://github.com/akonwi/git-plus/issues/448)
- Fix #517 [pr #514](https://github.com/akonwi/git-plus/issues/517)

### 5.22.0

- Adds a new command to do `git push -u`.
  - The old push command automatically retried after a failure with the `-u` flag and that can completely ignore some pre-push hooks. Fixes [#422](https://github.com/akonwi/git-plus/issues/422)
- Files can now be staged from the Tree-view with a Git add command in the context menu from right clicking files and folders.
  - More commands can be added there with pull requests. See [#422](https://github.com/akonwi/git-plus/issues/422)
  - This work also fixes an unreported bug where trying to open a difftool for a file from the tree-view that was different than the currently active file would not work.

### 5.21.0

- Includes a format option for the Git Show command in package settings. [pr #527](https://github.com/akonwi/git-plus/issues/527)

### 5.20.0

- Fix #510 [pr #514](https://github.com/akonwi/git-plus/issues/514)
- Add new command (Add Modified) [pr #519](https://github.com/akonwi/git-plus/issues/519)

### 5.19.0

- Add new command (Merge without fast-forward) [pr #492](https://github.com/akonwi/git-plus/issues/492)

### 5.18.3

- Merge [pr #489](https://github.com/akonwi/git-plus/issues/489)

### 5.18.2

- Git show defaults to HEAD if input is left empty. [pr #481](https://github.com/akonwi/git-plus/issues/481)
- Pin icon in status bar can now be disabled. [pr #488](https://github.com/akonwi/git-plus/issues/488)

### 5.18.0

- Enable activating the difftool on files and folders in the tree-view [pr #508](https://github.com/akonwi/git-plus/issues/508)
- Allow the package to initialize immediately when atom loads

### 5.17.1

- Fix bugs with new diff highlighting [#511](https://github.com/akonwi/git-plus/issues/511)

### 5.17.0

- Add syntax highlighting to diffs [#507](https://github.com/akonwi/git-plus/issues/507)
- Improves diff grammar and styling [#507](https://github.com/akonwi/git-plus/issues/507)

### 5.16.2

- Fix [#476](https://github.com/akonwi/git-plus/issues/476)

### 5.16.1

- Fix [#472](https://github.com/akonwi/git-plus/issues/472)

### 5.16.0

- Add toggle for experimental features in package settings
- Verbose commits is now an experimental feature([#90](https://github.com/akonwi/git-plus/issues/90))

### 5.15.0

- New command to 'Add and commit and push' (@john-d-murphy)[#452](https://github.com/akonwi/git-plus/issues/452)
- New command 'Open all changed files' (@flexoid) [#463](https://github.com/akonwi/git-plus/issues/463)

### 5.14.0

- Add a new stash command to save with a message -> [#396](https://github.com/akonwi/git-plus/issues/396)
- Fix placeholder text for Run command not displaying

### 5.13.6

- Fix [#445](https://github.com/akonwi/git-plus/issues/445)

### 5.13.5

- Fix [#412](https://github.com/akonwi/git-plus/issues/412)
- Slight refactor to diff grammar

### 5.13.4

- Fix [#423](https://github.com/akonwi/git-plus/issues/423)

### 5.13.3

- Show errors when Add and Push commands fail

### 5.13.0

- Add keyboard support for git log view (@aki77)[PR#389](https://github.com/akonwi/git-plus/pull/389)

### 5.12.3

- Fix [#387](https://github.com/akonwi/git-plus/issues/387)
- Fix [#383](https://github.com/akonwi/git-plus/issues/383)
- Fix [#369](https://github.com/akonwi/git-plus/issues/369)

### 5.12.1

- Merge [pr #380](https://github.com/akonwi/git-plus/issues/380)
- Merge [pr #381](https://github.com/akonwi/git-plus/issues/381)
- Fixes [#372](https://github.com/akonwi/git-plus/issues/372)
- Fix [#377](https://github.com/akonwi/git-plus/issues/377)

### 5.12.0

- Add `Merge Remote` command (@crshd)
- Fix [#370](https://github.com/akonwi/git-plus/issues/370)
- Fix [#371](https://github.com/akonwi/git-plus/issues/371)
- Remove code that 'fixed' [#90](https://github.com/akonwi/git-plus/issues/90) because there are still gaps to figure out

### 5.11.0

- Fix [#355](https://github.com/akonwi/git-plus/issues/355)
- Fix [#354](https://github.com/akonwi/git-plus/issues/354)
- Fix [#358](https://github.com/akonwi/git-plus/issues/358)

### 5.9.0

- Fix a bug where the commit amend file didn't show the status of the previous
  commit if there were no new changed files
- Fix for a blank uncommented line inside the status of the amend file
- Fix syntax error in the amend file. Changed 'removed' to 'deleted'

### 5.8.3

- Show errors from `Diff` command

### 5.8.2

- Fix for no notifications when changing branches

### 5.8.1

- Remove verbose commit feature because it isn't fully implemented

### 5.8.0

- Add setting for verbose commit panes

### 5.7.1

- Fix #349 (@joshbaldock)

### 5.7.0

- Added config options for pulling before pushing

### 5.6.10

- Fix #340 (@brettle)

### 5.6.8

- Fix #322 (@teefax)
- Change format of list of commands in README (@capncodewash)

### 5.6.6

- Fix #322 (@mightydok)
- Make all notifications dismissable (@jamen)
- Fix height for long log outputs (@sxasraf)

### 5.6.5

- Trigger checkout from clicking on branch name in status bar on atom-workspace
- Update splitPaneDirection config to be an enum

### 5.6.3

- Fix #318

### 5.6.2

- Disable color for 'Git show' (@modosc)

### 5.6.1

- Display untracked files in list of files to stage as separate items

### 5.6.0

- Fix #270. When pulling, you now have the default option to pull from the origin of the current branch

### 5.5.7

- Fix #317 and #319

### 5.5.6

- Fix #315

### 5.5.5

- Complete fix for #310

### 5.5.4

- Refactor
- Try to ignore CRLF errors when commiting

### 5.5.3

- Fix #311

### 5.5.2

- Refactoring
- Catch unstage files errors

### 5.5.0

- A lot of refactoring into promises
- **Output console**
  - Add toggle on the right of status-bar for toggling the output console
  - Output from `Git Run` will be displayed in the output console
  - Show notification when Push/Pull/Fetch starts in the output console
  - Show bigger messages like results of stash/merge in output console
- Clicking on the branch name in the status-bar will trigger the `Git Checkout` menu (@kandros)
- Amending no longer resets HEAD so you can safely cancel an amend
- **`Add All Commit And Push`**
  - is now an activation command (@dbenson24)
  - it tries to `pull` before pushing (@mhuggins7278)
- Add `Git Difftool` to open up a difftool (@outsmirkable)
- Add `Git Rebase` (@afontaine)

### 5.4.7

- #269

### 5.4.6

- Refactor to fix #266

### 5.4.5

- #265

### 5.4.4

- #263

### 5.4.3

- Add deactivate method to package
- Refactoring

### 5.4.2

- #261

### 5.4.1

- #260: Destroy 'COMMIT_EDITMSG' pane not just editor

### 5.4.0

- #201: Add `Commit All` command. Equivalent of `git commit -a`

### 5.3.5

- #209: Only destroy textEditor for 'COMMIT_EDITMSG'

### 5.3.4

- unlink COMMIT_EDITMSG file after commits
- Respect no 'open pane' setting with commit window

### 5.3.3

- #231: Shift-Enter confirms stage/unstage in dialogs

### 5.3.2

- Fix #226: remove COMMIT_EDITMSG file from repo when committing
- Fix #228: Don't show color codes in diff when `color.ui=always`

### 5.3.0

- Fix #233 (@hotoiledgoblins)
- Add 'Git checkout remote' to atom command palette
- Respect `commit.template` config option

### 5.2.4

- Fix #243
- Fix #42
- Add 'push' command to context menu

### 5.2.3

- Make git-diff highlighting non-greedy. Thanks to @Victorystick

### 5.2.2

- fix 'Git log current file'

### 5.2.1

- add support for Git pull using rebase (@maxcnunes)
- Git diff opens panes with respect to the 'open in pane' setting
- Commit and diff won't explode if you don't have the spit panes option selected

### 5.1.7

- Git log command now works with submodules and different repos
- new command: `Remote Checkout`

### 5.1.2

- #206: Fix for commit file syntax highlighting not working sometimes. (@Gwasanaethau)

### 5.1.1

- Fix for commands not working in submodules
- Fix typos with 'Git Fetch Prune' (@Azakur4)

### 5.1.0

- The Split Pane direction setting actually works now.
  > Possible choices are [right up down left]. Defaults to right.

### 5.0.7

- Fix #199
- Fix #198
- Fix #197

### 5.0.4

- Fix typo of 'notifer' to 'notifier'
- Fix issue #139

### 5.0.3

- Treeview and StatusBar should update after git commands
- No longer opening blank file on `Git show` if given an invalid object

### 5.0.2

- Fix typo of 'notifer' to 'notifier'
- Brought back the `messageTimeout` setting for remaining StatusViews

### 5.0.1

- Major release to be compatible with atom 1.0.0
- If a window has more than one project with a git repository and a command is attempted,
  then you can choose which repo to manipulate.
- New layout for commits in `Git log` command
- Most StatusViews of command output have been moved to the new notificaton system in atom

### 4.5.0

- Remove some more deprecations (@Azakur4)
- New command `Git Add All Commit And Push` (@TwanoO67)

### 4.4.13

- bug fix for those using 1.0.0 preview

### 4.4.12

- bug fix, issue #175

### 4.4.11

- Remove deprecated api code
- Add keywords to package.json
- Fix refreshing git status after commands to update ui
- Remove 'emissary' module because it does not work in helping Status and Output views listen for global events

### 4.4.10

- Remove uses of `atom.project.getRepo()`

### 4.4.9

- Refactoring
- Fixes issue #173

### 4.4.8

- Proper fix for GitRepository trying to refresh on window focus by setting `refreshOnWindowFocus` to false

### 4.4.7

- Update style selectors for diff highlighting

### 4.4.6

- Try to keep only one instance of GitRepository floating around by using either
  `atom.project.getRepo` or calling `::destroy` on an opened instance

### 4.4.2

- Gracefully handle `Git not found error` thanks to @TrangPham.
- Fix for files not opening when selected from status list

### 4.4.1

- Fix for `Git status` not opening selected file when accessed outside of repo.
- Fix for some commands working after second time they are selected

### 4.4.0

- Many internal upgrades to keep up with atom 1.0.0 api
- Commands can now be run from the Git-plus palette for files in other repos outside of the current project.
- This means you can open a directory of multiple Git repositories and work with individual repos while in the same project.

### 4.3.8

- minor

### 4.3.7

- More api upgrades
- No longer showing git commands in regular command palette when project is not a repo

### 4.3.6

- Making changes to follow the api for atom 1.0.0

### 4.3.5

- Update css selectors and keymappings with new atom API standards

### 4.3.2

- Fix for `Checkout new branch`

### 4.3.1

- `Git Show` can be cancelled with escape

### 4.3.0

- Confirm on `Git Remove`

### 4.2.6

- Handle case of no available panes after saving commit message

### 4.2.5

- Handle case of no available panes after closing commit message pane

### 4.2.4

- Minor patch

### 4.2.3

- Temporary fix for `Git Pull` issue on yosemite mac's thanks to @Azakur4.

### 4.2.2

- Remove hyphenated package name in menu

### 4.2.1

- Small fix in git-commit.coffee line 90 where promise returns a TextBuffer. Using given TextBuffer for subscriptions
  rather than the 'buffer' property in the TextBuffer.

### 4.2.0

- New Git merge feature thanks to @herlon214

### 4.1.2

- Using new atom api for configs and subscribing to make it easier for moving forward and maintenance

### 4.1.1

- Fix issue of commit tab not opening
- Still need to remove dependency on Theorist

### 4.1.0

- Return of git-plus command palette

### 4.0.0

- THIS IS THE LAST PUSH OF NEW FEATURES. I'm stopping development of this package because I don't have time and on top of that, I don't use atom anymore
- Adding new command called 'Git Run'. This allows you to run git commands like in the command line. i.e. `add --all .` or `clone git@github.com:akonwi/git-plus my-git-plus`
- Removed Git-Plus command palette and merged all commands into atom command palette
- all commands are now accessible via keymappings
- Add setting to change message display time in seconds

### 3.10.4

- Fix for object names being shortened unnecessarily.

### 3.10.3

- Fix for branch names being shortened unnecessarily.

### 3.10.2

- Fix 'Git Log' for windows users

### 3.10.1

- Git pull lists remotes if there are multiple and remote branches

### 3.9.0

- From the Git Status list, you can go to the modified file or open its diff file

### 3.8.0

- Adding commands for Git stash

### 3.7.0

- new `Reset HEAD` allows unstaging all changes

### 3.6.2

- Patch to resolve when atom project is a subfolder of a repository

### 3.6.1

- Can change commentchar in Git configs and Git-plus will use it in commit messages

### 3.6.0

- Can now push tags to remote

### 3.5.0

- The more common commands are now accessible through keybindings

  - Add
  - Add all and commit
  - Add and commit
  - Commit
  - Diff [all]
  - Log
  - Status
  - Pull
  - Push

### 3.4.0

- Debut of submodule support by the plugin.

- Submodule commands should be run while a submodule file is the current file

### 3.3.2

- Fix for not being able to commit on windows

### 3.3.0

- New setting to specify where to open the pane for commits and such...

### 3.1.0

- Git-palette doesn't show 'Git-plus:' prefix in front of commands.

- Add `diff`, `diff all`, `log`, to startup commands in regular command palette

### 3.0.2

- Should be able to close the views with feedback from commands through the `core:cancel` command.

### 3.0.0

#### Includes massive amounts of refactoring to internal api

- Dedicated command palette for git commands. Can be opened with
  `[cmd|ctrl]-shift-h`

- `Git init` is available in projects that are not git repos.

- Stage/Unstage multiple files at a time.

- Stage individual hunks of a changed file.

- `Git checkout all files`

- Cherry pick commits.

- Can also set the path to git in settings if it isn't in PATH.

### 2.11.3

- handling null results of getRepo()

### 2.11.2

- Fix hide-output key mapping

### 2.11.1

- Minor fix, changing a call of `@pushTo` to `@execute`

### 2.11.0

- Add hide-output keymapping

### 2.10.1

- Fix for missing fuzzaldrin reference

### 2.10.0

- `Git remove`

### 2.9.0

- `Git fetch`

### 2.8.0

- `Git log`
  Can also configure how many commits to show in log

- `Git show` commits of current file

- Tree-view gets refreshed after things

- Polish up git tips in commit message
