#include <bits/stdc++.h>

#define FASTIO ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)

#define ll long long
#define ull unsigned ll

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define pii pair<int, int>
#define pll pair<ll, ll>
#define mii map<int, int>

#define deb(x) cout << #x << "=" << x << '\n';

#define MOD 1000000007
using namespace std;

//////////////////////////////////////////////////////////////
//const ll INF = 0xFFFFFFFFFFFFFFFL;
//clock_t time_p = clock();
//
//void abhigyan10() {
//    time_p = clock() - time_p;
//    cerr << "Time Taken : " << (float) (time_p) / CLOCKS_PER_SEC << "\n";
//}
//
//ll seed;
//mt19937 rng(seed = chrono::steady_clock::now().time_since_epoch().count());
//
//inline ll rnd(ll l = 0, ll r = INF) {
//    return uniform_int_distribution<ll>(l, r)(rng);
//}
//
//#define clrbuf cin.ignore(numeric_limits<streamsize>::max(),'\n');
//#define preciset(x) cout<<setprecision(x)<<fixed;
//////////////////////////////////////////////////////////

ll pow(ll base, ll power) {
    ll result = 1;     // Initialize result

    base = base % MOD; // Update base if it is more than or
    // equal to p

    if (base == 0)
        return 0; // In case base is divisible by p;

    while (power > 0) {
        // If power is odd, multiply base with result
        if (power & 1)
            result = (result * base) % MOD;

        // power must be even now
        power = power >> 1; // power = power/2
        base = (base * base) % MOD;
    }
    return result;
}

ll mod(ll num) {
    return (num >= 0) ? num : -1 * num;
}

//helper function displays sorted data
template<class T>
void printQueue(T &q) {
    while (!q.empty()) {
        cout << q.top() << endl;
        q.pop();
    }
}


//class compare {
//public:
//    bool operator()(Node &a, Node &b) { // overloading both operators
//        return a.w < b.w: // if you want increasing order;(i.e increasing for minPQ)
////        return a.w > b.w // if you want reverse of default order;(i.e decreasing for minPQ)
//    }
//};

void forces() {
//    int n;
//    cin >> n;
//    vi arr(n);
//    mii freq;
//
//    for (int i = 0; i < n; ++i) {
//        cin >> arr[i];
//        ++freq[arr[i]];
//    }
//
//    priority_queue<pii > mypq;
//
//    for (auto x : freq) {
//        mypq.push(pair(x.first, x.second));
//    }
    int n;
    cin >> n;
    ll curr = 0, jump_no = 1;


    for (int i = 0; i < n; ++i) {
        curr += jump_no;
        if (curr >= n)
            break;
        ++jump_no;
    }

    cout << jump_no + curr - n << '\n';


}

void chef() {
    int n;
    cin >> n;

    vi arr(n);
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }


}

class Complex {
private:
    int real, img;

public:

    Complex(int r = 0, int i = 0) {
        real = r;
        img = i;
    }

    bool operator==(Complex &aaa) const {
        if (real == aaa.real && img == aaa.img)
            return true;
        return false;
    }

    Complex operator+(Complex &aaa) const {
        Complex temp;
        temp.real = real + aaa.real;
        temp.img = img + aaa.img;
        return temp;
    }

    void print_val() {
        cout << real << " +i" << img << '\n';
    }

};


int main() {
    FASTIO;

#ifndef ONLINE_JUDGE
    freopen("/home/hritwik/CLionProjects/contest/input.txt", "r+", stdin);
//    freopen("./output.txt", "w", stdout);
//    freopen("./error.txt", "w", stderr);
#endif

    // STRESS TEST
//    while (true) {
//        int n = rand() % 4 + 1;
//        cout << n << '\n';
//
//        vector<int> arr(n);
//        for (int i = 0; i < n; ++i) {
//            arr[i] = rand() % 1000000000;
//        }
//
//
//        for (int x: arr)
//            cout << x << ' ';
//        cout << '\n';
//
//        int res1 = fast(n, arr);
//        int res2 = slow(n, arr);
//
//        if (res1 != res2)
//            cout << "WA " << res1 << ' ' << res2 << '\n';
//         else
//            cout << "OK\n";
//
//    }

    int test = 1;
    cin >> test;

    while (test--) {
        forces();
//        chef();
    }


//    Complex a(10, 204), b(10, 20);
//    cout << (a == b) << "\n";
//    Complex c = (a + b);
//    c.print_val();


    return 0;
}
