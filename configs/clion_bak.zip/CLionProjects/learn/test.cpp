#pragma once
#include <iostream>

using namespace std;

void print() {
    cout << "HELLO";
}