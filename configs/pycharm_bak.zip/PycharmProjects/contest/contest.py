# a = list(map(int, input().split()))

# my_list = [[1, 2], [0, 2], [2, 1], [1, 1], [2, 2], [2, 0], [0, 1], [1, 0], [0, 0]]
# my_list = (sorted(my_list, key=lambda k: [k[0], k[1]]))

# this is client
from socket import *
import traceback
import json


# # address = input("Enter address")
# address = '192.168.29.11'
# port = 4206
# try:
#     clso = socket(AF_INET, SOCK_DGRAM)
#
#     print('Client running...')
#     message = bytes("Hello, from Client...", encoding='utf-8')
#     clso.sendto(message, (address, port))
#     print('Client: Hello')
#
#     while True:
#         receive_mssg, serAdd = clso.recvfrom(2048)
#         receive_mssg = str(receive_mssg, encoding='utf-8')
#         print("Server: ", receive_mssg)
#
#         # message = bytes(input("Enter Client message: "), encoding='utf-8')
#         message = bytes(input("Client: "), encoding='utf-8')
#         clso.sendto(message, (address, port))
# except ConnectionResetError or ConnectionAbortedError or ConnectionRefusedError:
#     print('Make sure server is running...')
#     print('Aborting....')
#     traceback.print_exc()

print("test")
