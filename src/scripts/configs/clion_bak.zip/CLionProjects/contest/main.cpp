#include <bits/stdc++.h>

using namespace std;


//////////////////////////////////////////////////////////////
//const ll INF = 0xFFFFFFFFFFFFFFFL;
//clock_t time_p = clock();
//
//void time_the_code() {
//    time_p = clock() - time_p;
//    cerr << "Time Taken : " << (float) (time_p) / CLOCKS_PER_SEC << "\n";
//}
//
//ll seed;
//mt19937 rng(seed = chrono::steady_clock::now().time_since_epoch().count());
//
//inline ll rnd(ll l = 0, ll r = INF) {
//    return uniform_int_distribution<ll>(l, r)(rng);
//}
//
//#define clrbuf cin.ignore(numeric_limits<streamsize>::max(),'\n');
//#define preciset(x) cout<<setprecision(x)<<fixed;
//////////////////////////////////////////////////////////


/**********************************************************/
/********** Definations, Macros and Debug Stuff  **********/

#define FASTIO ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)

#define ll long long
#define ull unsigned ll

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define pii pair<int, int>
#define pll pair<ll, ll>
#define mii map<int, int>

#define deb(x) cout << #x << "=" << x << '\n';
#define debug(...) cerr << "[" << #__VA_ARGS__ << "]: ", debug_out(__VA_ARGS__)
#define nl cout << '\n';


void debug_out() { cerr << '\n'; }

template<typename Head, typename... Tail>
void debug_out(Head H, Tail... T) {
    cerr << " " << to_string(H);
    debug_out(T...);
}

#define MOD 1000000007 // MOD = 10^9 + 7

/**********************************************************/

/**************** Frequently used functions ***************/

template<typename T>
inline void print_vector(vector<T> &a) {
    for (auto &x : a)
        cout << x << ' ';
    cout << endl;
}

inline ll pow_mod(ll base, ll power, ll mod = MOD) {
    ll result = 1;     // Initialize result

    base = base % mod; // Update base if it is more than or
    // equal to p

    if (base == 0)
        return 0; // In case base is divisible by p;

    while (power > 0) {
        // If power is odd, multiply base with result
        // this is binary exponentiation being done here
        if (power & 1)
            result = (result * base) % mod;

        // power must be even now
        power = power >> 1; // power = power/2
        base = (base * base) % mod;
    }
    return result;
}

inline ll binary_pow(ll a, ll b) {
    ll res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a;
        a = a * a;
        b >>= 1;
    }
    return res;
}

inline ll mod_add(ll a, ll b, ll m = MOD) {
    a = a % m;
    b = b % m;
    return (((a + b) % m) + m) % m;
}

inline ll mod_mul(ll a, ll b, ll m = MOD) {
    a = a % m;
    b = b % m;
    return (((a * b) % m) + m) % m;
}

inline ll mod_sub(ll a, ll b, ll m = MOD) {
    a = a % m;
    b = b % m;
    return (((a - b) % m) + m) % m;
}


inline ll mminvprime(ll a, ll b) {
    return pow_mod(a, b - 2, b);
}


inline ll mod_div(ll a, ll b, ll m = MOD) {
    a = a % m;
    b = b % m;
    return (mod_mul(a, mminvprime(b, m), m) + m) % m;
}

void sieve_of_erat(int n, vector<int> &ans) {

    bool prime[n + 1];
    memset(prime, true, sizeof(prime));

    for (int p = 2; p * p <= n; p++) {
        // If prime[p] is not changed,
        // then it is a prime
        if (prime[p] == true) {
            // Update all multiples
            // of p greater than or
            // equal to the square of it
            // numbers which are multiple
            // of p and are less than p^2
            // are already been marked.
            for (int i = p * p; i <= n; i += p)
                prime[i] = false;
        }
    }

    // Print all prime numbers
    for (int p = 2; p <= n; p++)
        if (prime[p]) {
            ans.push_back(p);
        }
}


/**********************************************************/
/**********************************************************/
/**          Chef              **/



void chef_q1() {
    int n;
    cin >> n;
    vll arr(n), brr(n), crr(n);
    map<ll, vector<int>> my_map;
    ll min_b = INT_MAX;

    for (int i = 0; i < n; ++i)
        cin >> arr[i];

    for (int i = 0; i < n; ++i) {
        cin >> brr[i];

        crr[i] = brr[i] % n;
        my_map[brr[i]].push_back(i);
        if (arr[i] < min_b) {
            min_b = arr[i];
        }
    }

    // printing
    for (int i = 0; i < n; ++i) {
        cout << arr[i] << " ";
    }
    nl
    for (int i = 0; i < n; ++i) {
        cout << brr[i] << " ";
    }
    nl
    for (int i = 0; i < n; ++i) {
        cout << crr[i] << " ";
    }
    nl
    for (auto &x: my_map) {
        cout << x.first << "-> ";
        for (auto y: x.second) {
            cout << y << " ";
        }
        cout << '\n';
    }
    // printing




    nl
}


void chef() {
    FASTIO;
#ifndef ONLINE_JUDGE
    freopen("/home/hritwik/Projects/CLionProjects/contest/input.txt", "r+", stdin);
    freopen("/home/hritwik/Projects/CLionProjects/contest/output.txt", "w", stdout);
//    freopen("./error.txt", "w", stderr);
#endif

    int test = 1;
    cin >> test;

    while (test--) {
        chef_q1();
    }


}

/**********************************************************/
/**********************************************************/
/**          Forces          **/


void forces_q1() {
    ull n;
    cin >> n;

    ull slice = 0;
    slice += n / 10;
    n %= 10;
    slice += n / 8;
    n %= 8;
    slice += n / 6;
    n %= 6;
    slice += n;

    double ans = (double )n * 2.5;
    cout << ans << "\n";


}


void forces() {
    FASTIO;
#ifndef ONLINE_JUDGE
    freopen("/home/hritwik/Projects/CLionProjects/contest/input.txt", "r+", stdin);
    freopen("/home/hritwik/Projects/CLionProjects/contest/output.txt", "w", stdout);
//    freopen("./error.txt", "w", stderr);
#endif

    int test = 1;
    cin >> test;

    while (test--) {
        forces_q1();
    }
}

/**********************************************************/
/**********************************************************/
/**          Main             **/

int main() {
    // STRESS TEST
//    srand(time(0));
//    while (true) {
//        int n = rand() % 10 + 1;
//        cout << n << '\n';
//
//        vector<int> arr(n);
//        for (int i = 0; i < n; ++i) {
//            arr[i] = rand() % 100;
//        }
//
//
//        for (int x: arr)
//            cout << x << ' ';
//        cout << '\n';
//
//        ll fast_sol = fast(n, arr);
//        ll slow_sol = slow(n, arr);
//
//        if (fast_sol != slow_sol) {
//            cout << "WA, Your= " << fast_sol << ", correct= " << slow_sol << '\n';
//            int temp;
//            cin >> temp;
//        } else
//            cout << "OK\n";
//
//    }

//    chef();
    forces();

    return 0;
}
