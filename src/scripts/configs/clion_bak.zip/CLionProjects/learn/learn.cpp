#include <bits/stdc++.h>
#include "test.h"

#define fastio ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define ull unsigned long long

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> pii;
typedef long long ll;

typedef map<pair<char, int>, int> edges;

//void build_trie(vector<edges> &trie, vector<string> &patterns) {
//    edges root;
//    trie.emplace_back(root);
//
//    for (auto &pattern: patterns) {
//        ull curr_node_num = 0;
//        int i = 1;
//        ull last = pattern.length();
//
//
//        for (char &letter : pattern) {
//            int br = 0;
//            for (auto &ele: trie[curr_node_num]) {
//                if (ele.first.first == letter) {
//                    if (i == last)
//                        ele.second = 1;
//
//                    curr_node_num = ele.first.second;
//                    br = 1;
//                    break;
//                }
//            }
//
//            if (!br) {
//                edges new_node;
//                trie.push_back(new_node);
//                if (i == last)
//                    trie[curr_node_num].emplace(make_pair(letter, trie.size() - 1), 1);
//                else
//                    trie[curr_node_num].emplace(make_pair(letter, trie.size() - 1), 0);
//
//                curr_node_num = trie.size() - 1;
//                i++;
//                continue;
//            }
//
//            i++;
//        }
//
//    }
//
//}

// Build a suffix tree of the string text and return a vector
// with all of the labels of its edges (the corresponding
// substrings of the text) in any order.

void ComputeSuffixTreeEdges(const string &text, vector<string> &edges) {
    // Implement this function yourself

}

void suffix_tree() {
    string text;
    cin >> text;

    vector<string> edges;
    ComputeSuffixTreeEdges(text, edges);
    for (auto &edge : edges) {
        cout << edge << '\n';
    }
}


int main() {
    fastio;

//    suffix_tree();
    print();

    return 0;
}
