#include <bits/stdc++.h>

#define FASTIO ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)

#define ll long long
#define ull unsigned ll

#define vi vector<int>
#define vll vector<ll>
#define vvi vector<vi>
#define pii pair<int, int>
#define pll pair<ll, ll>
#define mii map<int, int>

#define deb(x) cout << #x << "=" << x << '\n';

#define MOD 1000000007 // MOD = 10^9 + 7

using namespace std;


ll pow_mod(ll base, ll power) {
    ll result = 1;     // Initialize result

    base = base % MOD; // Update base if it is more than or
    // equal to p

    if (base == 0)
        return 0; // In case base is divisible by p;

    while (power > 0) {
        // If power is odd, multiply base with result
        // this is binary exponentiation being done here
        if (power & 1)
            result = (result * base) % MOD;

        // power must be even now
        power = power >> 1; // power = power/2
        base = (base * base) % MOD;
    }
    return result;
}

void sieve_of_erat(int n, vector<int> &ans) {

    bool prime[n + 1];
    memset(prime, true, sizeof(prime));

    for (int p = 2; p * p <= n; p++) {
        // If prime[p] is not changed,
        // then it is a prime
        if (prime[p] == true) {
            // Update all multiples
            // of p greater than or
            // equal to the square of it
            // numbers which are multiple
            // of p and are less than p^2
            // are already been marked.
            for (int i = p * p; i <= n; i += p)
                prime[i] = false;
        }
    }

    // Print all prime numbers
    for (int p = 2; p <= n; p++)
        if (prime[p]) {
            ans.push_back(p);
        }
}

void swap(int *x, int *y) {
    int temp = *x;
    *y = *x;
    *x = temp;
}

int main() {
    FASTIO;
#ifndef ONLINE_JUDGE
    freopen("/home/hritwik/CLionProjects/learn/input.txt", "r+", stdin);
//    freopen("./output.txt", "w", stdout);
//    freopen("./error.txt", "w", stderr);
#endif


    int test = 1;
    cin >> test;


    while (test--) {
        int n;
        cin >> n;

    }

    return 0;
}
