# import cv2
# import pytesseract
#
# import numpy as np
# from zipfile import ZipFile
#
# import PIL
# from PIL import Image
#
# pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'
#
#
# def resize_image(small_img, scale_percent):
#     # small image is numpy array, scale percent is int
#
#     width = int(small_img.shape[1] * scale_percent / 100)
#     height = int(small_img.shape[0] * scale_percent / 100)
#     return cv2.resize(small_img, (width, height))
#
#
# def create_sheet(width, height, rgb_color=(0, 0, 0)):
#     """Create new image(numpy array) filled with certain color in RGB"""
#     # Create black blank image
#     image = np.zeros((height, width, 3), np.uint8)
#
#     # Since OpenCV uses BGR, convert the color first
#     color = tuple(reversed(rgb_color))
#     # Fill image with color
#     image[:] = color
#
#     return image
#
#
# def start(word, zip):
#     archive = ZipFile(zip, 'r')
#     names = [x for x in archive.namelist()]
#     i = -1
#     for name in archive.infolist():
#         i += 1
#         img_data = archive.read(name)
#         color_img = cv2.imdecode(np.frombuffer(img_data, np.uint8), 1)
#         img = cv2.cvtColor(color_img, cv2.COLOR_BGR2GRAY)
#
#         text = pytesseract.image_to_string(img)
#         if word in text:
#             print("Results found in file", names[i])
#             faces = face_cascade.detectMultiScale(img, 1.35)
#             if len(faces) == 0:
#                 print("But there were no faces in that file!")
#                 continue
#             contact_sheet = create_sheet(1000, 1000)
#
#             currX = 0
#             currY = 0
#             max_height = 0
#
#             for face in faces:
#                 x, y, w, h = [v for v in face]
#
#                 # color_img = cv2.rectangle(color_img, (x, y), (x + w, y + h), (0, 0, 255), 3)
#                 crop_img = color_img[y:y + h, x:x + w]
#
#                 height, width, channels = crop_img.shape
#                 if height > max_height:
#                     max_height = height
#
#                 if currX + width >= contact_sheet.shape[1]:
#                     currX = 0
#                     currY += max_height
#                     max_height = 0
#
#                 contact_sheet[currY: currY + height, currX:currX + width] = crop_img
#                 currX += width
#
#             save_name = 'testfile_' + str(len(faces)) + '.jpg'
#             cv2.imwrite(save_name, contact_sheet)
#
#
# face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
# # start('Mark', 'images.zip')
# # start('Chris', 'small_img.zip')

# this is server

# from socket import *
#
# port = 4206
#
# seso = socket(AF_INET, SOCK_DGRAM)
# seso.bind(('', port))
# print('server is ready to receive')
# while True:
# 	message, clientAddr = seso.recvfrom(2048)
# 	message = str(message, encoding='utf-8')
# 	print("Client: ", message)
#
# 	# new_mess = bytes(input("Enter Server message: "), encoding='utf-8')
# 	new_mess = bytes(input("Server: "), encoding='utf-8')
# 	seso.sendto(new_mess, clientAddr)

import re


def myfun():
    statement = 'bababaaaabbbb bababa'

    x = re.findall(r".*bab.*", statement)
    print(x)


myfun()
