# this is client
import math
from socket import *
import traceback
import json

# # address = input("Enter address")
# address = '192.168.29.11'
# port = 4206
# try:
#     clso = socket(AF_INET, SOCK_DGRAM)
#
#     print('Client running...')
#     message = bytes("Hello, from Client...", encoding='utf-8')
#     clso.sendto(message, (address, port))
#     print('Client: Hello')
#
#     while True:
#         receive_mssg, serAdd = clso.recvfrom(2048)
#         receive_mssg = str(receive_mssg, encoding='utf-8')
#         print("Server: ", receive_mssg)
#
#         # message = bytes(input("Enter Client message: "), encoding='utf-8')
#         message = bytes(input("Client: "), encoding='utf-8')
#         clso.sendto(message, (address, port))
# except ConnectionResetError or ConnectionAbortedError or ConnectionRefusedError:
#     print('Make sure server is running...')
#     print('Aborting....')
#     traceback.print_exc()

for _ in range(65):
    # x = 4
    # print(f'{_} XOR {x} = {_ ^ x}')
    # print(str(bin(_))[2:], f'= {_}')
    pass

