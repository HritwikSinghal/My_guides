#

def get_curr_cgpa():
    my_dict = {
        'A': 10,
        'AB': 9,
        'B': 8,
        'BC': 7,
        'C': 6,
        'CD': 5,
        'D': 4,
        'F': 0
    }

    gpa_file = open('GPA', 'r+')
    lines = [x.strip() for x in gpa_file.readlines()]

    new_lines = []
    for x in lines:
        new_lines.append(x.split()[2:])

    for x in new_lines:
        x.pop()

    grades = []
    hours = []

    for x in new_lines:
        grades.append(x[-2].replace('-', '').strip())
        hours.append(int(x[-1]))
        x.pop()
        x.pop()

    my_credits = 0
    total_credits = 0
    for x in range(len(grades)):
        credits_for_this_subject = my_dict[grades[x]] * int(hours[x])
        my_credits += credits_for_this_subject
        TC_for_TS = int(hours[x]) * 10
        total_credits += TC_for_TS

        print(new_lines[x], grades[x], hours[x], credits_for_this_subject)

    print("\nYour cred:", my_credits)
    print("Total cred:",total_credits)
    print("current CGPA:", my_credits * 10 / total_credits)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    get_curr_cgpa()
